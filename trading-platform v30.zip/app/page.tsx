import type { Metadata } from "next"
import Link from "next/link"
import { TradingDashboard } from "@/components/trading-dashboard"
import { Logo } from "@/components/logo"
import { CookieConsent } from "@/components/cookie-consent"

export const metadata: Metadata = {
  title: "TradeFlex | Modern Trading Platform",
  description: "A modern trading platform for stocks, crypto, and more.",
}

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <Logo />
          <nav className="flex items-center space-x-4 lg:space-x-6 mx-6">
            <Link href="/" className="text-sm font-medium transition-colors text-primary">
              Dashboard
            </Link>
            <Link href="#" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
              Markets
            </Link>
            <Link href="#" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
              Portfolio
            </Link>
            <Link href="#" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
              News
            </Link>
          </nav>
          {/* Auth buttons are now handled by the TradingDashboard component */}
          <div className="ml-auto">{/* UserNav is rendered inside TradingDashboard */}</div>
        </div>
      </header>
      <main className="flex-1">
        <TradingDashboard />
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-14 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © 2024 TradeFlex. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="/terms" className="hover:text-foreground">
              Terms
            </Link>
            <Link href="/privacy" className="hover:text-foreground">
              Privacy
            </Link>
            <Link href="#" className="hover:text-foreground">
              Contact
            </Link>
          </div>
        </div>
      </footer>
      <CookieConsent />
    </div>
  )
}
