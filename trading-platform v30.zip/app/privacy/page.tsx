import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function PrivacyPage() {
  return (
    <div className="container max-w-4xl py-12">
      <Link href="/" className="flex items-center text-sm mb-8 hover:underline">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Dashboard
      </Link>

      <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>

      <div className="prose prose-sm dark:prose-invert max-w-none">
        <p className="text-muted-foreground mb-4">Last updated: April 19, 2025</p>

        <h2 className="text-xl font-semibold mt-8 mb-4">1. Introduction</h2>
        <p>
          At TradeFlex, we respect your privacy and are committed to protecting your personal data. This Privacy Policy
          explains how we collect, use, disclose, and safeguard your information when you use our trading platform.
        </p>
        <p>
          Please read this Privacy Policy carefully. If you do not agree with the terms of this Privacy Policy, please
          do not access the platform.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">2. Information We Collect</h2>
        <p>We collect several types of information from and about users of our platform, including:</p>
        <ul className="list-disc pl-6 mb-4">
          <li>Personal identifiable information such as name, email address, phone number, and date of birth.</li>
          <li>Financial information such as bank account details, credit card information, and transaction history.</li>
          <li>Identity verification information such as government-issued ID, passport, or driver's license.</li>
          <li>Technical data such as IP address, browser type, device information, and cookies.</li>
          <li>Usage data such as trading activity, platform preferences, and interaction with features.</li>
        </ul>

        <h2 className="text-xl font-semibold mt-8 mb-4">3. How We Collect Your Information</h2>
        <p>We collect information directly from you when you:</p>
        <ul className="list-disc pl-6 mb-4">
          <li>Register for an account</li>
          <li>Complete our KYC (Know Your Customer) process</li>
          <li>Make deposits or withdrawals</li>
          <li>Execute trades</li>
          <li>Contact our customer support</li>
          <li>Participate in surveys or promotions</li>
        </ul>
        <p>
          We also collect information automatically through cookies and similar technologies when you use our platform.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">4. Cookies and Similar Technologies</h2>
        <p>
          We use cookies and similar tracking technologies to enhance your experience on our platform. Cookies are small
          text files that are stored on your device when you visit our website. They help us remember your preferences,
          provide secure authentication, and improve platform performance.
        </p>
        <p>We use the following types of cookies:</p>
        <ul className="list-disc pl-6 mb-4">
          <li>
            <strong>Essential Cookies:</strong> These cookies are necessary for the website to function properly and
            cannot be disabled. They enable core functionality such as security, authentication, and remembering your
            preferences.
          </li>
          <li>
            <strong>Analytics Cookies:</strong> These cookies help us understand how visitors interact with our website
            by collecting and reporting information anonymously. This helps us improve our platform based on user
            behavior.
          </li>
          <li>
            <strong>Functional Cookies:</strong> These cookies enable enhanced functionality and personalization, such
            as remembering your chart preferences, timeframes, and trading settings.
          </li>
        </ul>
        <p>
          You can control and manage cookies through your browser settings. Please note that removing or blocking
          certain cookies may impact your experience on our platform and limit certain functionality.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">5. How We Use Your Information</h2>
        <p>We use your information for various purposes, including:</p>
        <ul className="list-disc pl-6 mb-4">
          <li>Providing and maintaining our trading platform</li>
          <li>Processing your transactions</li>
          <li>Verifying your identity and preventing fraud</li>
          <li>Complying with legal and regulatory requirements</li>
          <li>Improving our platform and customer experience</li>
          <li>Communicating with you about your account, updates, and promotions</li>
          <li>Analyzing usage patterns and trends</li>
        </ul>

        <h2 className="text-xl font-semibold mt-8 mb-4">6. How We Share Your Information</h2>
        <p>We may share your information with:</p>
        <ul className="list-disc pl-6 mb-4">
          <li>Service providers who perform services on our behalf</li>
          <li>Financial institutions and payment processors to facilitate transactions</li>
          <li>Identity verification services to comply with KYC requirements</li>
          <li>Legal and regulatory authorities when required by law</li>
          <li>Business partners for joint marketing efforts (with your consent)</li>
        </ul>
        <p>We do not sell your personal information to third parties.</p>

        <h2 className="text-xl font-semibold mt-8 mb-4">7. Data Security</h2>
        <p>
          We implement appropriate technical and organizational measures to protect your personal information from
          unauthorized access, disclosure, alteration, and destruction.
        </p>
        <p>
          However, no method of transmission over the Internet or electronic storage is 100% secure. While we strive to
          use commercially acceptable means to protect your personal information, we cannot guarantee its absolute
          security.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">8. Your Data Protection Rights</h2>
        <p>Depending on your location, you may have the following rights regarding your personal information:</p>
        <ul className="list-disc pl-6 mb-4">
          <li>Right to access your personal information</li>
          <li>Right to rectify inaccurate or incomplete information</li>
          <li>Right to erasure (right to be forgotten)</li>
          <li>Right to restrict processing</li>
          <li>Right to data portability</li>
          <li>Right to object to processing</li>
          <li>Right to withdraw consent</li>
        </ul>
        <p>To exercise these rights, please contact us using the information provided in the "Contact Us" section.</p>

        <h2 className="text-xl font-semibold mt-8 mb-4">9. Children's Privacy</h2>
        <p>
          Our platform is not intended for individuals under the age of 18. We do not knowingly collect personal
          information from children under 18. If you are a parent or guardian and you are aware that your child has
          provided us with personal information, please contact us.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">10. Changes to This Privacy Policy</h2>
        <p>
          We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new
          Privacy Policy on this page and updating the "Last updated" date.
        </p>
        <p>
          You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are
          effective when they are posted on this page.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">11. Contact Us</h2>
        <p>If you have any questions about this Privacy Policy, please contact us at privacy@tradeflex.com.</p>
      </div>
    </div>
  )
}
