"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Camera, CreditCard, DollarSign, Trash, ArrowUpToLine } from "lucide-react"

// Update the interface to include bio
interface ProfileModalProps {
  open: boolean
  onClose: () => void
  username: string
  accountBalance: number
  profilePicture: string | null
  bio: string | null
  onBalanceUpdate: (newBalance: number) => void
  onProfileUpdate: (data: { username: string; profilePicture?: string; bio?: string }) => void
}

// Update the function parameters to include bio
export function ProfileModal({
  open,
  onClose,
  username,
  accountBalance,
  profilePicture,
  bio: initialBio,
  onBalanceUpdate,
  onProfileUpdate,
}: ProfileModalProps) {
  const [activeTab, setActiveTab] = useState("profile")
  const [displayName, setDisplayName] = useState(username)
  const [email, setEmail] = useState(`${username.toLowerCase().replace(/\s+/g, "")}@example.com`)
  const [bio, setBio] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("userBio") || initialBio || ""
    }
    return initialBio || ""
  })
  const [localProfilePicture, setLocalProfilePicture] = useState<string | null>(null)
  const [darkModeNotifications, setDarkModeNotifications] = useState(true)
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [loading, setLoading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  // Payment methods
  const [paymentMethods, setPaymentMethods] = useState([
    { id: 1, type: "Credit Card", last4: "4242", expiry: "12/25", default: true },
    { id: 2, type: "PayPal", email: "user@example.com", default: false },
  ])

  // Transaction history
  const transactions = [
    { id: 1, type: "deposit", amount: 5000, date: "2024-04-15", status: "completed" },
    { id: 2, type: "withdrawal", amount: 1200, date: "2024-04-10", status: "completed" },
    { id: 3, type: "deposit", amount: 2500, date: "2024-04-05", status: "completed" },
  ]

  // Initialize localProfilePicture from props when the component mounts or when profilePicture changes
  useEffect(() => {
    setLocalProfilePicture(profilePicture)
  }, [profilePicture])

  // Handle profile picture upload
  const handleProfilePictureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // In a real app, you would upload this to a server
    // For this demo, we'll use a local URL
    const reader = new FileReader()
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setLocalProfilePicture(reader.result)
      }
    }
    reader.readAsDataURL(file)
  }

  // Update the handleProfileUpdate function
  const handleProfileUpdate = () => {
    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      setLoading(false)

      // Save bio to localStorage
      if (typeof window !== "undefined") {
        localStorage.setItem("userBio", bio)
      }

      onProfileUpdate({
        username: displayName,
        profilePicture: localProfilePicture || undefined,
        bio: bio, // Pass bio to the parent component
      })

      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      })
    }, 1000)
  }

  // Handle setting default payment method
  const handleSetDefaultPayment = (id: number) => {
    setPaymentMethods(
      paymentMethods.map((method) => ({
        ...method,
        default: method.id === id,
      })),
    )

    toast({
      title: "Default Payment Updated",
      description: "Your default payment method has been updated.",
    })
  }

  // Handle removing payment method
  const handleRemovePayment = (id: number) => {
    setPaymentMethods(paymentMethods.filter((method) => method.id !== id))

    toast({
      title: "Payment Method Removed",
      description: "Your payment method has been removed.",
    })
  }

  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part.charAt(0))
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Account Settings</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-4">
            <div className="flex flex-col items-center mb-6">
              <div className="relative">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={localProfilePicture || "/placeholder.svg?height=96&width=96"} alt={displayName} />
                  <AvatarFallback className="text-2xl">{getInitials(displayName)}</AvatarFallback>
                </Avatar>
                <Button
                  size="icon"
                  variant="secondary"
                  className="absolute bottom-0 right-0 rounded-full h-8 w-8"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Camera className="h-4 w-4" />
                </Button>
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept="image/*"
                  onChange={handleProfilePictureUpload}
                />
              </div>
              <p className="text-sm text-muted-foreground mt-2">Click the camera icon to change your profile picture</p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="displayName">Display Name</Label>
                <Input id="displayName" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  placeholder="Tell us about yourself"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="resize-none"
                  rows={4}
                />
              </div>

              <div className="text-xs text-muted-foreground bg-muted p-3 rounded-md">
                <p className="font-medium mb-1">Privacy Notice</p>
                <p>
                  Your profile data is stored locally on your device and is not shared with any third parties. We use
                  secure local storage to save your preferences and profile information.
                </p>
              </div>

              <Button onClick={handleProfileUpdate} disabled={loading} className="w-full">
                {loading ? "Updating..." : "Update Profile"}
              </Button>
            </div>
          </TabsContent>

          {/* Billing Tab */}
          <TabsContent value="billing" className="space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Account Balance</CardTitle>
                <CardDescription>Manage your account balance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Current Balance</span>
                    <span className="text-xl font-bold">
                      $
                      {accountBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        onClose()
                        // Trigger deposit modal from parent component
                        setTimeout(() => {
                          document
                            .querySelector('[data-deposit-button="true"]')
                            ?.dispatchEvent(new MouseEvent("click", { bubbles: true }))
                        }, 100)
                      }}
                    >
                      <DollarSign className="h-4 w-4 mr-2" />
                      Deposit Funds
                    </Button>
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        onClose()
                        // Trigger withdrawal modal from parent component
                        setTimeout(() => {
                          document
                            .querySelector('[data-withdrawal-button="true"]')
                            ?.dispatchEvent(new MouseEvent("click", { bubbles: true }))
                        }, 100)
                      }}
                      disabled={accountBalance <= 0}
                    >
                      <ArrowUpToLine className="h-4 w-4 mr-2" />
                      Withdraw Funds
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Payment Methods</CardTitle>
                <CardDescription>Manage your payment methods</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {paymentMethods.map((method) => (
                    <div key={method.id} className="flex items-center justify-between p-3 border rounded-md">
                      <div className="flex items-center gap-3">
                        {method.type === "Credit Card" ? (
                          <CreditCard className="h-5 w-5 text-muted-foreground" />
                        ) : (
                          <DollarSign className="h-5 w-5 text-muted-foreground" />
                        )}
                        <div>
                          <p className="font-medium">{method.type}</p>
                          <p className="text-sm text-muted-foreground">
                            {method.type === "Credit Card"
                              ? `•••• ${method.last4} | Expires ${method.expiry}`
                              : method.email}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {!method.default && (
                          <Button variant="outline" size="sm" onClick={() => handleSetDefaultPayment(method.id)}>
                            Set Default
                          </Button>
                        )}
                        {method.default && (
                          <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-md">Default</span>
                        )}
                        <Button variant="ghost" size="icon" onClick={() => handleRemovePayment(method.id)}>
                          <Trash className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}

                  <Button variant="outline" className="w-full">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Add Payment Method
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Transaction History</CardTitle>
                <CardDescription>Recent account activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {transactions.map((transaction) => (
                    <div key={transaction.id} className="flex justify-between items-center py-2 border-b last:border-0">
                      <div>
                        <p className="font-medium capitalize">{transaction.type}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(transaction.date).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p
                          className={`font-medium ${transaction.type === "deposit" ? "text-green-500" : "text-red-500"}`}
                        >
                          {transaction.type === "deposit" ? "+" : "-"}${transaction.amount.toLocaleString()}
                        </p>
                        <p className="text-xs text-muted-foreground capitalize">{transaction.status}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Preferences Tab */}
          <TabsContent value="preferences" className="space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Appearance</CardTitle>
                <CardDescription>Customize your trading experience</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Default Chart Type</p>
                      <p className="text-sm text-muted-foreground">Choose your preferred chart type</p>
                    </div>
                    <Select defaultValue="line">
                      <SelectTrigger className="w-[140px]">
                        <SelectValue placeholder="Chart Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="line">Line Chart</SelectItem>
                        <SelectItem value="candle">Candle Chart</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Default Time Frame</p>
                      <p className="text-sm text-muted-foreground">Set your default time frame</p>
                    </div>
                    <Select defaultValue="1h">
                      <SelectTrigger className="w-[140px]">
                        <SelectValue placeholder="Time Frame" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1m">1 Minute</SelectItem>
                        <SelectItem value="5m">5 Minutes</SelectItem>
                        <SelectItem value="15m">15 Minutes</SelectItem>
                        <SelectItem value="1h">1 Hour</SelectItem>
                        <SelectItem value="1d">1 Day</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Dark Mode Notifications</p>
                      <p className="text-sm text-muted-foreground">Receive notifications in dark mode</p>
                    </div>
                    <Switch checked={darkModeNotifications} onCheckedChange={setDarkModeNotifications} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Notifications</CardTitle>
                <CardDescription>Manage your notification preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Email Notifications</p>
                      <p className="text-sm text-muted-foreground">Receive updates via email</p>
                    </div>
                    <Switch checked={emailNotifications} onCheckedChange={setEmailNotifications} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Price Alerts</p>
                      <p className="text-sm text-muted-foreground">Get notified about price changes</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Trade Confirmations</p>
                      <p className="text-sm text-muted-foreground">Receive confirmations for trades</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Market News</p>
                      <p className="text-sm text-muted-foreground">Get updates about market news</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
