"use client"

import { useEffect, useRef, useState } from "react"
import { useTheme } from "@/components/theme-provider"
import { fetchHistoricalData, fetchCandleData } from "@/lib/market-data"

interface TradingChartProps {
  symbol: string
  timeFrame: string
  chartType: "line" | "candle"
  chartColor?: string
}

interface ChartData {
  prices: number[]
  timestamps: number[]
}

interface CandleData {
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume?: number
}

// Helper function to get color values based on the selected color
function getChartColors(colorName: string, isDarkMode: boolean): { lineColor: string; fillColor: string } {
  switch (colorName) {
    case "green":
      return {
        lineColor: "#22c55e", // Green
        fillColor: isDarkMode ? "rgba(34, 197, 94, 0.1)" : "rgba(34, 197, 94, 0.05)",
      }
    case "purple":
      return {
        lineColor: "#a855f7", // Purple
        fillColor: isDarkMode ? "rgba(168, 85, 247, 0.1)" : "rgba(168, 85, 247, 0.05)",
      }
    case "orange":
      return {
        lineColor: "#f97316", // Orange
        fillColor: isDarkMode ? "rgba(249, 115, 22, 0.1)" : "rgba(249, 115, 22, 0.05)",
      }
    case "red":
      return {
        lineColor: "#ef4444", // Red
        fillColor: isDarkMode ? "rgba(239, 68, 68, 0.1)" : "rgba(239, 68, 68, 0.05)",
      }
    case "blue":
    default:
      return {
        lineColor: "#3b82f6", // Blue
        fillColor: isDarkMode ? "rgba(59, 130, 246, 0.1)" : "rgba(59, 130, 246, 0.05)",
      }
  }
}

export function TradingChart({ symbol, timeFrame, chartType, chartColor = "blue" }: TradingChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { theme } = useTheme()
  const isDarkMode = theme === "dark"
  const [lineData, setLineData] = useState<ChartData>({ prices: [], timestamps: [] })
  const [candleData, setCandleData] = useState<CandleData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [liveUpdateCount, setLiveUpdateCount] = useState(0)

  // Fetch line chart data
  useEffect(() => {
    if (chartType !== "line") return

    let isMounted = true
    const fetchData = async () => {
      try {
        if (!isMounted) return
        setLoading(true)
        setError(null)

        // Add a small delay to prevent too many API calls at once
        await new Promise((resolve) => setTimeout(resolve, 100))

        const data = await fetchHistoricalData(symbol, timeFrame)

        if (!isMounted) return

        // Validate the data before setting it
        if (data && data.prices && data.prices.length > 0 && data.timestamps && data.timestamps.length > 0) {
          setLineData(data)
        } else {
          console.error("Invalid historical data received:", data)
          setError("Received invalid chart data")
        }
      } catch (err) {
        if (!isMounted) return
        console.error(`Error fetching historical data for ${symbol}:`, err)
        setError(`Failed to load chart data: ${err instanceof Error ? err.message : "Unknown error"}`)
      } finally {
        if (isMounted) {
          setLoading(false)
        }
      }
    }

    fetchData()

    // Set up polling for live data
    let interval: NodeJS.Timeout | null = null
    if (timeFrame === "live") {
      // For live mode, update more frequently
      interval = setInterval(() => {
        if (isMounted) {
          fetchData()
          // Increment update counter to force re-render
          setLiveUpdateCount((count) => count + 1)
        }
      }, 1000) // Update every second for more dynamic live mode
    }

    return () => {
      isMounted = false
      if (interval) clearInterval(interval)
    }
  }, [symbol, timeFrame, chartType])

  // Fetch candle chart data
  useEffect(() => {
    if (chartType !== "candle") return

    let isMounted = true
    const fetchData = async () => {
      try {
        if (!isMounted) return
        setLoading(true)
        setError(null)

        // Add a small delay to prevent too many API calls at once
        await new Promise((resolve) => setTimeout(resolve, 100))

        const data = await fetchCandleData(symbol, timeFrame)

        if (!isMounted) return

        // Validate the data before setting it
        if (data && Array.isArray(data) && data.length > 0) {
          setCandleData(data)
        } else {
          console.error("Invalid candle data received:", data)
          setError("Received invalid chart data")
        }
      } catch (err) {
        if (!isMounted) return
        console.error(`Error fetching candle data for ${symbol}:`, err)
        setError(`Failed to load chart data: ${err instanceof Error ? err.message : "Unknown error"}`)
      } finally {
        if (isMounted) {
          setLoading(false)
        }
      }
    }

    fetchData()

    // Set up polling for live data
    let interval: NodeJS.Timeout | null = null
    if (timeFrame === "live") {
      // For live mode, update more frequently
      interval = setInterval(() => {
        if (isMounted) {
          fetchData()
          // Increment update counter to force re-render
          setLiveUpdateCount((count) => count + 1)
        }
      }, 1000) // Update every second for more dynamic live mode
    }

    return () => {
      isMounted = false
      if (interval) clearInterval(interval)
    }
  }, [symbol, timeFrame, chartType])

  // Draw chart
  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const setDimensions = () => {
      const parent = canvas.parentElement
      if (!parent) return

      canvas.width = parent.clientWidth
      canvas.height = 400
    }

    setDimensions()
    window.addEventListener("resize", setDimensions)

    // Get colors based on theme and selected chart color
    const { lineColor, fillColor } = getChartColors(chartColor, isDarkMode)

    // Set colors based on theme
    const gridColor = isDarkMode ? "#374151" : "#e5e7eb"
    const textColor = isDarkMode ? "#9ca3af" : "#6b7280"
    const bullishColor = "#22c55e"
    const bearishColor = "#ef4444"

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw loading state
    if (loading) {
      ctx.fillStyle = textColor
      ctx.font = "16px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("Loading chart data...", canvas.width / 2, canvas.height / 2)
      return
    }

    // Draw error state
    if (error) {
      ctx.fillStyle = bearishColor
      ctx.font = "16px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(error, canvas.width / 2, canvas.height / 2)
      return
    }

    // Draw line chart
    if (chartType === "line" && lineData.prices.length > 0) {
      // Find min and max values for scaling
      const minValue = Math.min(...lineData.prices) * 0.99
      const maxValue = Math.max(...lineData.prices) * 1.01
      const range = maxValue - minValue

      // Draw grid
      ctx.strokeStyle = gridColor
      ctx.lineWidth = 0.5

      // Horizontal grid lines
      for (let i = 0; i <= 5; i++) {
        const y = canvas.height - canvas.height * (i / 5)
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(canvas.width, y)
        ctx.stroke()

        // Price labels
        const price = minValue + range * (i / 5)
        ctx.fillStyle = textColor
        ctx.font = "12px sans-serif"
        ctx.textAlign = "left"
        ctx.fillText(`${price.toLocaleString(undefined, { maximumFractionDigits: price > 1000 ? 0 : 2 })}`, 5, y - 5)
      }

      // Draw line chart
      ctx.strokeStyle = lineColor // Use the selected color
      ctx.lineWidth = 2
      ctx.beginPath()

      lineData.prices.forEach((value, index) => {
        const x = (canvas.width / (lineData.prices.length - 1)) * index
        const y = canvas.height - ((value - minValue) / range) * canvas.height

        if (index === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      })

      ctx.stroke()

      // Fill area under the line
      ctx.lineTo(canvas.width, canvas.height)
      ctx.lineTo(0, canvas.height)
      ctx.closePath()
      ctx.fillStyle = fillColor // Use the selected fill color
      ctx.fill()

      // Draw time labels
      if (lineData.timestamps.length > 0) {
        ctx.fillStyle = textColor
        ctx.font = "10px sans-serif"
        ctx.textAlign = "center"

        // Show a few time labels
        const labelCount = Math.min(6, lineData.timestamps.length)
        for (let i = 0; i < labelCount; i++) {
          const index = Math.floor((i * (lineData.timestamps.length - 1)) / (labelCount - 1))
          const x = (canvas.width / (lineData.timestamps.length - 1)) * index

          const date = new Date(lineData.timestamps[index])
          let timeLabel = ""

          if (timeFrame === "1y") {
            // For yearly chart, show month and year
            timeLabel = `${date.getMonth() + 1}/${date.getFullYear().toString().substr(2)}`
          } else if (timeFrame === "1M") {
            // For monthly chart, show day and month
            timeLabel = `${date.getMonth() + 1}/${date.getDate()}`
          } else if (timeFrame === "1d") {
            timeLabel = `${date.getMonth() + 1}/${date.getDate()}`
          } else if (timeFrame === "4h" || timeFrame === "1h") {
            timeLabel = `${date.getHours()}:00`
          } else {
            timeLabel = `${date.getHours()}:${date.getMinutes().toString().padStart(2, "0")}`
          }

          ctx.fillText(timeLabel, x, canvas.height - 5)
        }
      }

      // For live mode, add a pulsing dot at the end of the line
      if (timeFrame === "live" && lineData.prices.length > 0) {
        const lastPrice = lineData.prices[lineData.prices.length - 1]
        const lastX = canvas.width
        const lastY = canvas.height - ((lastPrice - minValue) / range) * canvas.height

        // Draw pulsing dot
        const pulseSize = 4 + Math.sin(Date.now() / 200) * 2 // Pulsing effect
        ctx.beginPath()
        ctx.arc(lastX - 5, lastY, pulseSize, 0, Math.PI * 2)
        ctx.fillStyle = lineColor
        ctx.fill()

        // Draw latest price
        ctx.font = "bold 12px sans-serif"
        ctx.fillStyle = lineColor
        ctx.textAlign = "right"
        ctx.fillText(
          `${lastPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
          canvas.width - 10,
          lastY - 10,
        )
      }
    }

    // Draw candle chart
    if (chartType === "candle" && candleData.length > 0) {
      // Find min and max values for scaling
      const allValues = candleData.flatMap((candle) => [candle.high, candle.low])
      const minValue = Math.min(...allValues) * 0.99
      const maxValue = Math.max(...allValues) * 1.01
      const range = maxValue - minValue

      // Draw grid
      ctx.strokeStyle = gridColor
      ctx.lineWidth = 0.5

      // Horizontal grid lines
      for (let i = 0; i <= 5; i++) {
        const y = canvas.height - canvas.height * (i / 5)
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(canvas.width, y)
        ctx.stroke()

        // Price labels
        const price = minValue + range * (i / 5)
        ctx.fillStyle = textColor
        ctx.font = "12px sans-serif"
        ctx.textAlign = "left"
        ctx.fillText(`${price.toLocaleString(undefined, { maximumFractionDigits: price > 1000 ? 0 : 2 })}`, 5, y - 5)
      }

      // Draw candles
      const candleWidth = (canvas.width / candleData.length) * 0.8
      const spacing = (canvas.width / candleData.length) * 0.2

      candleData.forEach((candle, index) => {
        const x = (canvas.width / candleData.length) * index + spacing / 2

        // Calculate y positions
        const openY = canvas.height - ((candle.open - minValue) / range) * canvas.height
        const closeY = canvas.height - ((candle.close - minValue) / range) * canvas.height
        const highY = canvas.height - ((candle.high - minValue) / range) * canvas.height
        const lowY = canvas.height - ((candle.low - minValue) / range) * canvas.height

        // Draw wick (high to low line)
        ctx.beginPath()
        ctx.moveTo(x + candleWidth / 2, highY)
        ctx.lineTo(x + candleWidth / 2, lowY)
        ctx.strokeStyle = candle.open > candle.close ? bearishColor : bullishColor
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw candle body
        ctx.fillStyle = candle.open > candle.close ? bearishColor : bullishColor
        const candleHeight = Math.abs(closeY - openY)
        const candleY = Math.min(openY, closeY)

        ctx.fillRect(x, candleY, candleWidth, candleHeight > 1 ? candleHeight : 1)
      })

      // Draw time labels
      if (candleData.length > 0) {
        ctx.fillStyle = textColor
        ctx.font = "10px sans-serif"
        ctx.textAlign = "center"

        // Show a few time labels
        const labelCount = Math.min(6, candleData.length)
        for (let i = 0; i < labelCount; i++) {
          const index = Math.floor((i * (candleData.length - 1)) / (labelCount - 1))
          const x = (canvas.width / candleData.length) * index + spacing / 2 + candleWidth / 2

          const date = new Date(candleData[index].timestamp)
          let timeLabel = ""

          if (timeFrame === "1y") {
            // For yearly chart, show month and year
            timeLabel = `${date.getMonth() + 1}/${date.getFullYear().toString().substr(2)}`
          } else if (timeFrame === "1M") {
            // For monthly chart, show day and month
            timeLabel = `${date.getMonth() + 1}/${date.getDate()}`
          } else if (timeFrame === "1d") {
            timeLabel = `${date.getMonth() + 1}/${date.getDate()}`
          } else if (timeFrame === "4h" || timeFrame === "1h") {
            timeLabel = `${date.getHours()}:00`
          } else {
            timeLabel = `${date.getHours()}:${date.getMinutes().toString().padStart(2, "0")}`
          }

          ctx.fillText(timeLabel, x, canvas.height - 5)
        }
      }

      // For live mode, highlight the last candle
      if (timeFrame === "live" && candleData.length > 0) {
        const lastCandle = candleData[candleData.length - 1]
        const lastX = (canvas.width / candleData.length) * (candleData.length - 1) + spacing / 2
        const closeY = canvas.height - ((lastCandle.close - minValue) / range) * canvas.height

        // Draw latest price
        ctx.font = "bold 12px sans-serif"
        ctx.fillStyle = lastCandle.open > lastCandle.close ? bearishColor : bullishColor
        ctx.textAlign = "right"
        ctx.fillText(
          `${lastCandle.close.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
          canvas.width - 10,
          closeY - 10,
        )
      }
    }

    return () => {
      window.removeEventListener("resize", setDimensions)
    }
  }, [chartType, lineData, candleData, loading, error, isDarkMode, timeFrame, chartColor, liveUpdateCount])

  return (
    <div className="w-full h-[400px] bg-card relative">
      <canvas ref={canvasRef} className="w-full h-full"></canvas>
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/50">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      )}
      {timeFrame === "live" && !loading && !error && (
        <div className="absolute top-2 left-2">
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-xs font-medium text-green-500">LIVE</span>
          </div>
        </div>
      )}
    </div>
  )
}
