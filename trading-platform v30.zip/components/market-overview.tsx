"use client"

import { useEffect, useState } from "react"
import { ArrowDown, ArrowUp } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { fetchMarketOverview, type MarketData } from "@/lib/market-data"

interface MarketOverviewProps {
  onSelectSymbol: (symbol: string) => void
}

export function MarketOverview({ onSelectSymbol }: MarketOverviewProps) {
  const [markets, setMarkets] = useState<MarketData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let isMounted = true
    const fetchData = async () => {
      try {
        setLoading(true)
        setError(null)

        // Add a small delay to prevent too many API calls at once
        await new Promise((resolve) => setTimeout(resolve, 100))

        const data = await fetchMarketOverview()

        if (!isMounted) return

        if (Array.isArray(data) && data.length > 0) {
          setMarkets(data)
        } else {
          throw new Error("Invalid market data received")
        }
      } catch (error) {
        if (!isMounted) return
        console.error("Error fetching market data:", error)
        setError("Failed to load market data")
      } finally {
        if (isMounted) {
          setLoading(false)
        }
      }
    }

    fetchData()

    // Refresh data every 30 seconds for more up-to-date information
    const interval = setInterval(fetchData, 30000)
    return () => {
      isMounted = false
      clearInterval(interval)
    }
  }, [])

  if (error) {
    return (
      <div className="p-4 text-center text-red-500">
        <p>{error}</p>
        <p className="text-sm text-muted-foreground mt-2">Please try again later</p>
      </div>
    )
  }

  return (
    <div>
      {loading && markets.length === 0 ? (
        <div className="flex justify-center py-4">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Symbol</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>24h Change</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {markets.map((market) => (
              <TableRow
                key={market.symbol}
                className="cursor-pointer hover:bg-muted/50"
                onClick={() => onSelectSymbol(market.symbol)}
              >
                <TableCell>
                  <div>
                    <div className="font-medium">{market.symbol}</div>
                    <div className="text-sm text-muted-foreground">{market.name}</div>
                  </div>
                </TableCell>
                <TableCell>
                  ${market.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </TableCell>
                <TableCell>
                  <div className={`flex items-center ${market.changePercent >= 0 ? "text-green-500" : "text-red-500"}`}>
                    {market.changePercent >= 0 ? (
                      <ArrowUp className="h-4 w-4 mr-1" />
                    ) : (
                      <ArrowDown className="h-4 w-4 mr-1" />
                    )}
                    {Math.abs(market.changePercent).toFixed(2)}%
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  )
}
