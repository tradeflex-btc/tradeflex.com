"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CookieIcon, X } from "lucide-react"

export function CookieConsent() {
  const [showConsent, setShowConsent] = useState(false)

  useEffect(() => {
    // Check if user has already made a choice
    const cookieConsent = localStorage.getItem("cookieConsent")

    // Only show the banner if no choice has been made yet
    if (!cookieConsent) {
      // Slight delay to avoid immediate popup when page loads
      const timer = setTimeout(() => {
        setShowConsent(true)
      }, 1000)

      return () => clearTimeout(timer)
    }
  }, [])

  const acceptAllCookies = () => {
    localStorage.setItem("cookieConsent", "accepted")
    setShowConsent(false)
  }

  const acceptEssentialCookies = () => {
    localStorage.setItem("cookieConsent", "essential")
    setShowConsent(false)
  }

  const closeConsent = () => {
    setShowConsent(false)
  }

  if (!showConsent) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4 md:p-6 animate-in fade-in slide-in-from-bottom-10">
      <Card className="mx-auto max-w-4xl shadow-lg border-2">
        <CardHeader className="pb-2 flex flex-row items-start justify-between">
          <div>
            <CardTitle className="text-lg flex items-center">
              <CookieIcon className="h-5 w-5 mr-2" />
              Cookie Preferences
            </CardTitle>
            <CardDescription>Manage your cookie settings</CardDescription>
          </div>
          <Button variant="ghost" size="icon" onClick={closeConsent} className="mt-0">
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="text-sm">
          <p className="mb-4">
            We use cookies to enhance your trading experience, personalize content, and analyze our traffic. Our cookies
            help us remember your preferences, provide secure authentication, and improve platform performance.
          </p>
          <div className="space-y-2">
            <div className="flex items-start">
              <div className="bg-primary/10 p-2 rounded-full mr-3 mt-1">
                <CookieIcon className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h4 className="font-medium">Essential Cookies</h4>
                <p className="text-muted-foreground text-xs">
                  These cookies are necessary for the website to function properly and cannot be disabled. They enable
                  core functionality such as security, authentication, and remembering your preferences.
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="bg-primary/10 p-2 rounded-full mr-3 mt-1">
                <CookieIcon className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h4 className="font-medium">Analytics Cookies</h4>
                <p className="text-muted-foreground text-xs">
                  These cookies help us understand how visitors interact with our website by collecting and reporting
                  information anonymously. This helps us improve our platform based on user behavior.
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="bg-primary/10 p-2 rounded-full mr-3 mt-1">
                <CookieIcon className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h4 className="font-medium">Functional Cookies</h4>
                <p className="text-muted-foreground text-xs">
                  These cookies enable enhanced functionality and personalization, such as remembering your chart
                  preferences, timeframes, and trading settings.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row gap-2 pt-2">
          <Button variant="outline" onClick={acceptEssentialCookies} className="w-full sm:w-auto">
            Essential Cookies Only
          </Button>
          <Button onClick={acceptAllCookies} className="w-full sm:w-auto">
            Accept All Cookies
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
