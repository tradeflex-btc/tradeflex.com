"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"

interface ThemeContextProps {
  theme: "light" | "dark"
  setTheme: (theme: "light" | "dark") => void
}

const ThemeContext = createContext<ThemeContextProps>({
  theme: "light",
  setTheme: () => {},
})

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const [theme, setTheme] = useState<"light" | "dark">("light")

  useEffect(() => {
    // Get the initial theme from localStorage or system preference
    const getInitialTheme = (): "light" | "dark" => {
      // Check if we're in the browser environment
      if (typeof window !== "undefined") {
        // Check localStorage first
        const storedTheme = localStorage.getItem("theme")
        if (storedTheme === "dark" || storedTheme === "light") {
          return storedTheme
        }

        // If no theme in localStorage, check system preference
        if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
          return "dark"
        }
      }

      // Default to light theme
      return "light"
    }

    setTheme(getInitialTheme())
  }, [])

  useEffect(() => {
    if (typeof window === "undefined") return

    // Save theme to localStorage
    localStorage.setItem("theme", theme)

    // Apply theme to document
    if (theme === "dark") {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [theme])

  return <ThemeContext.Provider value={{ theme, setTheme }}>{children}</ThemeContext.Provider>
}

export const useTheme = () => useContext(ThemeContext)
