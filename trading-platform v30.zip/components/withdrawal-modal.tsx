"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { ArrowUpToLine, Shield, AlertTriangle, Check } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface WithdrawalModalProps {
  open: boolean
  onClose: () => void
  accountBalance: number
  onSuccess: (amount: number) => void
}

export function WithdrawalModal({ open, onClose, accountBalance, onSuccess }: WithdrawalModalProps) {
  const [amount, setAmount] = useState("")
  const [bankName, setBankName] = useState("")
  const [accountNumber, setAccountNumber] = useState("")
  const [routingNumber, setRoutingNumber] = useState("")
  const [accountName, setAccountName] = useState("")
  const [withdrawalMethod, setWithdrawalMethod] = useState("bank")
  const [loading, setLoading] = useState(false)
  const [showVerification, setShowVerification] = useState(false)
  const [verificationCode, setVerificationCode] = useState("")
  const [withdrawalSuccess, setWithdrawalSuccess] = useState(false)
  const { toast } = useToast()

  // Reset form when modal opens
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setAmount("")
      setBankName("")
      setAccountNumber("")
      setRoutingNumber("")
      setAccountName("")
      setWithdrawalMethod("bank")
      setShowVerification(false)
      setVerificationCode("")
      setWithdrawalSuccess(false)
      onClose()
    }
  }

  // Handle withdrawal request
  const handleWithdrawal = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simple validation
    if (!amount || !bankName || !accountNumber || !routingNumber || !accountName) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    const withdrawalAmount = Number.parseFloat(amount)
    if (isNaN(withdrawalAmount) || withdrawalAmount <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    if (withdrawalAmount > accountBalance) {
      toast({
        title: "Insufficient Funds",
        description: "You don't have enough funds for this withdrawal",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    // Show verification step
    setShowVerification(true)
    setLoading(false)
  }

  // Handle verification code submission
  const handleVerificationSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simple validation
    if (!verificationCode || verificationCode.length < 6) {
      toast({
        title: "Error",
        description: "Please enter a valid verification code",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    // Simulate API call
    setTimeout(() => {
      setLoading(false)
      const withdrawalAmount = Number.parseFloat(amount)

      // Show success state
      setWithdrawalSuccess(true)

      // In a real app, you would process the withdrawal through a payment gateway
      setTimeout(() => {
        onSuccess(withdrawalAmount)
        onClose()
      }, 3000)
    }, 2000)
  }

  // Render success state
  if (withdrawalSuccess) {
    return (
      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Withdrawal Successful</DialogTitle>
          </DialogHeader>

          <div className="flex flex-col items-center justify-center py-6">
            <div className="rounded-full bg-green-100 p-3 dark:bg-green-900 mb-4">
              <Check className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Withdrawal Initiated</h3>
            <p className="text-center text-muted-foreground mb-4">
              Your withdrawal of ${Number.parseFloat(amount).toFixed(2)} has been initiated. Funds will be sent to your
              bank account.
            </p>
            <p className="text-sm text-muted-foreground">Withdrawals typically take 1-3 business days to process.</p>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Render verification step
  if (showVerification) {
    return (
      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Verify Your Withdrawal</DialogTitle>
          </DialogHeader>

          <Alert className="mb-4 bg-blue-50 border-blue-200 dark:bg-blue-950 dark:border-blue-800">
            <Shield className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            <AlertTitle className="text-blue-800 dark:text-blue-300">Security Verification</AlertTitle>
            <AlertDescription className="text-blue-700 dark:text-blue-400">
              For your security, we've sent a verification code to your registered email address.
            </AlertDescription>
          </Alert>

          <form onSubmit={handleVerificationSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="verification-code">Verification Code</Label>
              <Input
                id="verification-code"
                placeholder="Enter 6-digit code"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                maxLength={6}
              />
              <p className="text-sm text-muted-foreground">Please enter the 6-digit code sent to your email</p>
            </div>

            <div className="flex justify-between">
              <Button type="button" variant="outline" onClick={() => setShowVerification(false)}>
                Back
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? "Verifying..." : "Confirm Withdrawal"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Withdraw Funds</DialogTitle>
        </DialogHeader>

        <Alert className="mb-4 bg-amber-50 border-amber-200 dark:bg-amber-950 dark:border-amber-800">
          <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          <AlertDescription className="text-amber-700 dark:text-amber-400">
            You are withdrawing real money. All transactions are final and subject to our terms of service.
          </AlertDescription>
        </Alert>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Withdraw to Bank Account</CardTitle>
            <CardDescription>Funds will be sent to your bank account</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleWithdrawal} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="withdrawal-method">Withdrawal Method</Label>
                <Select value={withdrawalMethod} onValueChange={setWithdrawalMethod}>
                  <SelectTrigger id="withdrawal-method">
                    <SelectValue placeholder="Select withdrawal method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bank">Bank Transfer (ACH)</SelectItem>
                    <SelectItem value="wire">Wire Transfer</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="withdrawal-amount">Amount (USD)</Label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5">$</span>
                  <Input
                    id="withdrawal-amount"
                    type="number"
                    min="10"
                    max={accountBalance}
                    step="0.01"
                    placeholder="0.00"
                    className="pl-7"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    required
                  />
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Available Balance:</span>
                  <span className="font-medium">
                    ${accountBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bank-name">Bank Name</Label>
                <Input
                  id="bank-name"
                  placeholder="Enter your bank name"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="account-number">Account Number</Label>
                <Input
                  id="account-number"
                  placeholder="Enter your account number"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="routing-number">Routing Number</Label>
                <Input
                  id="routing-number"
                  placeholder="Enter your routing number"
                  value={routingNumber}
                  onChange={(e) => setRoutingNumber(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="account-name">Account Holder Name</Label>
                <Input
                  id="account-name"
                  placeholder="Enter account holder name"
                  value={accountName}
                  onChange={(e) => setAccountName(e.target.value)}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                <ArrowUpToLine className="h-4 w-4 mr-2" />
                {loading ? "Processing..." : "Continue to Verification"}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="px-6 py-3 border-t text-xs text-muted-foreground">
            <p>Withdrawals typically take 1-3 business days to process</p>
          </CardFooter>
        </Card>
      </DialogContent>
    </Dialog>
  )
}
