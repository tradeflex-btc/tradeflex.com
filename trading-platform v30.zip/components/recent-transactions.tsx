"use client"

import { ArrowDown, ArrowUp } from "lucide-react"

export function RecentTransactions() {
  const transactions = [
    { id: 1, type: "buy", symbol: "BTC/USD", amount: 0.15, price: 63250.5, total: 9487.58, time: "10:24 AM" },
    { id: 2, type: "sell", symbol: "ETH/USD", amount: 2.5, price: 3475.25, total: 8688.13, time: "09:15 AM" },
    { id: 3, type: "buy", symbol: "SOL/USD", amount: 10, price: 143.75, total: 1437.5, time: "Yesterday" },
    { id: 4, type: "buy", symbol: "AAPL", amount: 5, price: 174.5, total: 872.5, time: "Yesterday" },
    { id: 5, type: "sell", symbol: "BTC/USD", amount: 0.05, price: 62150.25, total: 3107.51, time: "Apr 15" },
  ]

  return (
    <div className="space-y-4">
      {transactions.map((transaction) => (
        <div key={transaction.id} className="flex items-center justify-between py-2 border-b last:border-0">
          <div className="flex items-center gap-3">
            <div
              className={`p-2 rounded-full ${transaction.type === "buy" ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"}`}
            >
              {transaction.type === "buy" ? <ArrowDown className="h-4 w-4" /> : <ArrowUp className="h-4 w-4" />}
            </div>
            <div>
              <div className="font-medium">
                {transaction.type === "buy" ? "Buy" : "Sell"} {transaction.symbol}
              </div>
              <div className="text-sm text-muted-foreground">{transaction.time}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="font-medium">${transaction.total.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">
              {transaction.amount} @ ${transaction.price.toLocaleString()}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
