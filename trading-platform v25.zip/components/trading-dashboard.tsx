"use client"

import type React from "react"

import { useState, useEffect } from "react"
import {
  ArrowDown,
  ArrowUp,
  BarChart4,
  DollarSign,
  LineChart,
  RefreshCw,
  Search,
  Settings,
  AlertTriangle,
  ArrowUpToLine,
} from "lucide-react"
import { TradingChart } from "@/components/trading-chart"
import { MarketOverview } from "@/components/market-overview"
import { OrderForm } from "@/components/order-form"
import { RecentTransactions } from "@/components/recent-transactions"
import { WatchList } from "@/components/watch-list"
import { TimeFrameSelector } from "@/components/time-frame-selector"
import { SettingsModal } from "@/components/settings-modal"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { useTheme } from "@/components/theme-provider"
import { getCurrentPrice, getBasePriceForSymbol } from "@/lib/market-data"
import { useToast } from "@/components/ui/use-toast"
import { AuthModal } from "@/components/auth-modal"
import { DepositModal } from "@/components/deposit-modal"
import { WithdrawalModal } from "@/components/withdrawal-modal"
import { UserNav } from "@/components/user-nav"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function TradingDashboard() {
  const [selectedSymbol, setSelectedSymbol] = useState("BTC/USD")
  const [currentPrice, setCurrentPrice] = useState(0)
  const [priceChange, setPriceChange] = useState(0)
  const [chartType, setChartType] = useState<"line" | "candle">("line")
  const [timeFrame, setTimeFrame] = useState("1h")
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [chartColor, setChartColor] = useState("blue")
  const [authModalOpen, setAuthModalOpen] = useState(false)
  const [depositModalOpen, setDepositModalOpen] = useState(false)
  const [withdrawalModalOpen, setWithdrawalModalOpen] = useState(false)
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signin")
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [username, setUsername] = useState("")
  const [accountBalance, setAccountBalance] = useState(0) // Starting with $0 balance
  const { theme } = useTheme()
  const { toast } = useToast()
  const [profilePicture, setProfilePicture] = useState<string | null>(null)
  const [showRealMoneyAlert, setShowRealMoneyAlert] = useState(true)
  const [showInsufficientFundsAlert, setShowInsufficientFundsAlert] = useState(false)

  // Load saved settings on component mount
  useEffect(() => {
    if (typeof window !== "undefined") {
      // Load chart color
      const savedChartColor = localStorage.getItem("chartColor")
      if (savedChartColor) {
        setChartColor(savedChartColor)
      }

      // Load chart type
      const savedChartType = localStorage.getItem("chartType")
      if (savedChartType === "line" || savedChartType === "candle") {
        setChartType(savedChartType)
      }

      // Load time frame
      const savedTimeFrame = localStorage.getItem("timeFrame")
      if (savedTimeFrame) {
        setTimeFrame(savedTimeFrame)
      }

      // Check if user is logged in (persistent login)
      const loggedInUser = localStorage.getItem("username")
      if (loggedInUser) {
        setIsLoggedIn(true)
        setUsername(loggedInUser)

        // Load profile picture
        const savedProfilePicture = localStorage.getItem("profilePicture")
        if (savedProfilePicture) {
          setProfilePicture(savedProfilePicture)
        }

        // Update last activity time
        localStorage.setItem("lastActivityTime", new Date().getTime().toString())

        // Load account balance
        const savedBalance = localStorage.getItem("accountBalance")
        if (savedBalance) {
          setAccountBalance(Number.parseFloat(savedBalance))
        }
      }
    }
  }, [])

  // Add a function to track user activity and update the last activity time
  useEffect(() => {
    if (isLoggedIn) {
      // Update last activity time whenever user interacts with the app
      const updateActivityTime = () => {
        localStorage.setItem("lastActivityTime", new Date().getTime().toString())
      }

      // Add event listeners to track user activity
      window.addEventListener("click", updateActivityTime)
      window.addEventListener("keypress", updateActivityTime)
      window.addEventListener("scroll", updateActivityTime)
      window.addEventListener("mousemove", updateActivityTime)

      return () => {
        // Clean up event listeners
        window.removeEventListener("click", updateActivityTime)
        window.removeEventListener("keypress", updateActivityTime)
        window.removeEventListener("scroll", updateActivityTime)
        window.removeEventListener("mousemove", updateActivityTime)
      }
    }
  }, [isLoggedIn])

  // Save account balance when it changes
  useEffect(() => {
    if (isLoggedIn) {
      localStorage.setItem("accountBalance", accountBalance.toString())
    }
  }, [accountBalance, isLoggedIn])

  // Fetch current price for the selected symbol
  useEffect(() => {
    let isMounted = true
    const fetchPrice = async () => {
      try {
        setLoading(true)
        // Add a small delay to prevent too many API calls at once
        await new Promise((resolve) => setTimeout(resolve, 100))

        let price
        if (selectedSymbol === "BTC/USD") {
          // Hardcode accurate Bitcoin price
          price = 84823.0
        } else {
          price = await getCurrentPrice(selectedSymbol)
        }

        if (!isMounted) return

        setCurrentPrice(price)
        // For simplicity, we're setting a random price change
        // In a real app, you'd calculate this from historical data
        setPriceChange(Math.random() * 4 - 2)
      } catch (error) {
        if (!isMounted) return
        console.error("Error fetching current price:", error)
        // Set fallback values if there's an error
        setCurrentPrice(getBasePriceForSymbol(selectedSymbol))
        setPriceChange(0)

        toast({
          title: "Error fetching price data",
          description: "Using fallback price data. Please try again later.",
          variant: "destructive",
        })
      } finally {
        if (isMounted) {
          setLoading(false)
        }
      }
    }

    fetchPrice()

    // Refresh price more frequently for better real-time experience
    const interval = setInterval(fetchPrice, 5000) // Update every 5 seconds
    return () => {
      isMounted = false
      clearInterval(interval)
    }
  }, [selectedSymbol, toast])

  // Handle symbol selection
  const handleSelectSymbol = (symbol: string) => {
    setSelectedSymbol(symbol)
  }

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (!searchQuery) return

    // Simple search implementation - in a real app, you'd have a more sophisticated search
    const query = searchQuery.toUpperCase()
    if (query.includes("BTC") || query.includes("BITCOIN")) {
      setSelectedSymbol("BTC/USD")
    } else if (query.includes("ETH") || query.includes("ETHEREUM")) {
      setSelectedSymbol("ETH/USD")
    } else if (query.includes("SOL") || query.includes("SOLANA")) {
      setSelectedSymbol("SOL/USD")
    } else if (query.includes("AAPL") || query.includes("APPLE")) {
      setSelectedSymbol("AAPL")
    } else if (query.includes("MSFT") || query.includes("MICROSOFT")) {
      setSelectedSymbol("MSFT")
    } else if (query.includes("GOOGL") || query.includes("GOOGLE")) {
      setSelectedSymbol("GOOGL")
    } else {
      toast({
        title: "Symbol not found",
        description: `Could not find symbol matching "${searchQuery}"`,
        variant: "destructive",
      })
    }

    setSearchQuery("")
  }

  // Manual refresh
  const updatePrice = async () => {
    try {
      setLoading(true)
      const price = await getCurrentPrice(selectedSymbol)
      setCurrentPrice(price)
      // Generate a random price change
      setPriceChange(Math.random() * 4 - 2)

      toast({
        title: "Price updated",
        description: `Latest price for ${selectedSymbol} loaded`,
      })
    } catch (error) {
      console.error("Error updating price:", error)
      toast({
        title: "Error updating price",
        description: "Failed to refresh price data. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Handle chart color change
  const handleChartColorChange = (color: string) => {
    setChartColor(color)
    localStorage.setItem("chartColor", color)

    toast({
      title: "Chart color updated",
      description: `Chart color set to ${color}`,
    })
  }

  // Handle sign in/sign up
  const handleOpenAuth = (mode: "signin" | "signup") => {
    setAuthMode(mode)
    setAuthModalOpen(true)
  }

  // Handle successful authentication
  const handleAuthSuccess = (user: { username: string }) => {
    setIsLoggedIn(true)
    setUsername(user.username)
    localStorage.setItem("username", user.username)

    // Set last login date
    const now = new Date().toISOString()
    localStorage.setItem("lastLoginDate", now)

    setAuthModalOpen(false)

    toast({
      title: authMode === "signin" ? "Signed in successfully" : "Account created successfully",
      description: `Welcome${authMode === "signin" ? " back" : ""}, ${user.username}!`,
    })

    // Show deposit prompt if balance is 0
    if (accountBalance === 0) {
      setTimeout(() => {
        setShowInsufficientFundsAlert(true)
      }, 1000)
    }
  }

  // Handle sign out
  const handleSignOut = () => {
    setIsLoggedIn(false)
    setUsername("")
    localStorage.removeItem("username")

    toast({
      title: "Signed out successfully",
      description: "You have been signed out of your account.",
    })
  }

  // Handle deposit
  const handleOpenDeposit = () => {
    if (!isLoggedIn) {
      toast({
        title: "Authentication required",
        description: "Please sign in to deposit funds",
        variant: "destructive",
      })
      handleOpenAuth("signin")
      return
    }

    setDepositModalOpen(true)
    setShowInsufficientFundsAlert(false)
  }

  // Handle withdrawal
  const handleOpenWithdrawal = () => {
    if (!isLoggedIn) {
      toast({
        title: "Authentication required",
        description: "Please sign in to withdraw funds",
        variant: "destructive",
      })
      handleOpenAuth("signin")
      return
    }

    if (accountBalance <= 0) {
      toast({
        title: "Insufficient funds",
        description: "You need to have funds in your account to make a withdrawal",
        variant: "destructive",
      })
      return
    }

    setWithdrawalModalOpen(true)
  }

  // Handle successful deposit
  const handleDepositSuccess = (amount: number) => {
    setAccountBalance((prev) => prev + amount)

    toast({
      title: "Deposit Successful",
      description: `${amount.toFixed(2)} has been added to your account`,
    })
  }

  // Handle successful withdrawal
  const handleWithdrawalSuccess = (amount: number) => {
    setAccountBalance((prev) => prev - amount)

    toast({
      title: "Withdrawal Successful",
      description: `${amount.toFixed(2)} has been withdrawn from your account`,
    })
  }

  // Add a handler for profile updates
  const handleProfileUpdate = (data: { username?: string; profilePicture?: string }) => {
    if (data.username) {
      setUsername(data.username)
      localStorage.setItem("username", data.username)
    }

    if (data.profilePicture) {
      setProfilePicture(data.profilePicture)
      localStorage.setItem("profilePicture", data.profilePicture)
    }
  }

  // Handle trade execution
  const handleTradeExecution = (tradeAmount: number) => {
    if (accountBalance < tradeAmount) {
      setShowInsufficientFundsAlert(true)
      toast({
        title: "Insufficient Funds",
        description: "Please deposit funds to complete this trade",
        variant: "destructive",
      })
      return false
    }

    return true
  }

  return (
    <div className="container py-6">
      {showRealMoneyAlert && (
        <Alert className="mb-4 bg-amber-50 border-amber-200 dark:bg-amber-950 dark:border-amber-800">
          <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          <AlertTitle className="text-amber-800 dark:text-amber-300">Real Money Trading</AlertTitle>
          <AlertDescription className="text-amber-700 dark:text-amber-400">
            You are trading with real money. All deposits, withdrawals, and trades involve actual currency. Please trade
            responsibly.
          </AlertDescription>
          <Button
            variant="outline"
            size="sm"
            className="mt-2 border-amber-300 text-amber-700 hover:bg-amber-100 dark:border-amber-700 dark:text-amber-300 dark:hover:bg-amber-900"
            onClick={() => setShowRealMoneyAlert(false)}
          >
            I understand
          </Button>
        </Alert>
      )}

      {showInsufficientFundsAlert && isLoggedIn && accountBalance === 0 && (
        <Alert className="mb-4 bg-blue-50 border-blue-200 dark:bg-blue-950 dark:border-blue-800">
          <DollarSign className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          <AlertTitle className="text-blue-800 dark:text-blue-300">Deposit Funds to Start Trading</AlertTitle>
          <AlertDescription className="text-blue-700 dark:text-blue-400">
            Your account balance is $0.00. Please deposit funds to start trading.
          </AlertDescription>
          <Button
            variant="outline"
            size="sm"
            className="mt-2 border-blue-300 text-blue-700 hover:bg-blue-100 dark:border-blue-700 dark:text-blue-300 dark:hover:bg-blue-900"
            onClick={handleOpenDeposit}
          >
            Deposit Now
          </Button>
        </Alert>
      )}

      <div className="flex flex-col gap-4 md:flex-row">
        <div className="w-full md:w-3/4 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold">{selectedSymbol}</h1>
              <div className="flex items-center gap-2">
                {loading ? (
                  <div className="animate-pulse bg-muted h-6 w-24 rounded"></div>
                ) : (
                  <>
                    <span className="text-xl font-semibold">
                      ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                    <span
                      className={`flex items-center text-sm ${priceChange >= 0 ? "text-green-500" : "text-red-500"}`}
                    >
                      {priceChange >= 0 ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
                      {Math.abs(priceChange).toFixed(2)}%
                    </span>
                  </>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={updatePrice} disabled={loading}>
                <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
                Refresh
              </Button>
              <Button variant="outline" size="sm" onClick={() => setSettingsOpen(true)}>
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
              <Button
                variant="default"
                size="sm"
                className="bg-green-600 hover:bg-green-700"
                onClick={handleOpenDeposit}
              >
                <DollarSign className="h-4 w-4 mr-2" />
                Deposit
              </Button>
              <form onSubmit={handleSearch} className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search markets..."
                  className="pl-8 w-[200px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </form>

              {/* User navigation component */}
              <UserNav
                isLoggedIn={isLoggedIn}
                username={username}
                accountBalance={accountBalance}
                profilePicture={profilePicture}
                onBalanceUpdate={setAccountBalance}
                onSignOut={handleSignOut}
                onOpenAuth={handleOpenAuth}
                onProfileUpdate={handleProfileUpdate}
              />
            </div>
          </div>

          <Card>
            <CardHeader className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Price Chart</CardTitle>
                  <CardDescription>Price movement</CardDescription>
                </div>
                <div className="flex gap-2">
                  <div className="flex mr-2">
                    <Button
                      variant={chartType === "line" ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setChartType("line")
                        localStorage.setItem("chartType", "line")
                      }}
                      className="rounded-r-none"
                    >
                      <LineChart className="h-4 w-4 mr-2" />
                      Line
                    </Button>
                    <Button
                      variant={chartType === "candle" ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setChartType("candle")
                        localStorage.setItem("chartType", "candle")
                      }}
                      className="rounded-l-none"
                    >
                      <BarChart4 className="h-4 w-4 mr-2" />
                      Candles
                    </Button>
                  </div>
                  <TimeFrameSelector
                    selectedTimeFrame={timeFrame}
                    onSelectTimeFrame={(tf) => {
                      setTimeFrame(tf)
                      localStorage.setItem("timeFrame", tf)
                    }}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <TradingChart
                symbol={selectedSymbol}
                timeFrame={timeFrame}
                chartType={chartType}
                chartColor={chartColor}
              />
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="p-4">
                <CardTitle>Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <RecentTransactions />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="p-4">
                <CardTitle>Market Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <MarketOverview onSelectSymbol={handleSelectSymbol} />
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="w-full md:w-1/4 space-y-4">
          <Card>
            <CardHeader className="p-4">
              <CardTitle>Place Order</CardTitle>
            </CardHeader>
            <CardContent>
              <OrderForm
                symbol={selectedSymbol}
                currentPrice={currentPrice}
                accountBalance={accountBalance}
                onTradeExecution={handleTradeExecution}
                onOpenDeposit={handleOpenDeposit}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="p-4">
              <CardTitle>Watchlist</CardTitle>
            </CardHeader>
            <CardContent>
              <WatchList onSelectSymbol={handleSelectSymbol} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="p-4">
              <CardTitle>Portfolio Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {isLoggedIn ? (
                  <>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Total Value</span>
                      <span className="font-semibold">
                        $
                        {accountBalance.toLocaleString(undefined, {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Available Cash</span>
                      <span className="font-semibold">
                        $
                        {accountBalance.toLocaleString(undefined, {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold"
                        onClick={handleOpenDeposit}
                      >
                        <DollarSign className="h-4 w-4 mr-2" />
                        Deposit
                      </Button>
                      <Button
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold"
                        onClick={handleOpenWithdrawal}
                        disabled={accountBalance <= 0}
                      >
                        <ArrowUpToLine className="h-4 w-4 mr-2" />
                        Withdraw
                      </Button>
                    </div>
                    {accountBalance === 0 && (
                      <p className="text-xs text-center text-amber-600 dark:text-amber-400 mt-2">
                        You need to deposit funds before you can start trading
                      </p>
                    )}
                  </>
                ) : (
                  <div className="space-y-4">
                    <p className="text-center text-muted-foreground">Sign in to view your portfolio</p>
                    <Button className="w-full" onClick={() => handleOpenAuth("signin")}>
                      Sign In
                    </Button>
                    <Button variant="outline" className="w-full" onClick={() => handleOpenAuth("signup")}>
                      Create Account
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
            {isLoggedIn && (
              <CardFooter className="px-4 py-3 border-t text-xs text-muted-foreground">
                <p>Funds are secured and insured up to $250,000</p>
              </CardFooter>
            )}
          </Card>
        </div>
      </div>

      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        onChartColorChange={handleChartColorChange}
        chartColor={chartColor}
      />

      <AuthModal
        open={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        mode={authMode}
        onSuccess={handleAuthSuccess}
      />

      <DepositModal
        open={depositModalOpen}
        onClose={() => setDepositModalOpen(false)}
        onSuccess={handleDepositSuccess}
      />

      <WithdrawalModal
        open={withdrawalModalOpen}
        onClose={() => setWithdrawalModalOpen(false)}
        accountBalance={accountBalance}
        onSuccess={handleWithdrawalSuccess}
      />
    </div>
  )
}
