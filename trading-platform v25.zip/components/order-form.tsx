"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { AlertCircle, DollarSign } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface OrderFormProps {
  symbol: string
  currentPrice: number
  accountBalance: number
  onTradeExecution: (amount: number) => boolean
  onOpenDeposit: () => void
}

export function OrderForm({ symbol, currentPrice, accountBalance, onTradeExecution, onOpenDeposit }: OrderFormProps) {
  const [orderType, setOrderType] = useState("market")
  const [quantity, setQuantity] = useState("1")
  const [price, setPrice] = useState(currentPrice.toString())
  const [total, setTotal] = useState(currentPrice.toString())
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showInsufficientFunds, setShowInsufficientFunds] = useState(false)
  const { toast } = useToast()

  const updateTotal = (qty: string, prc: string) => {
    const calculatedTotal = Number.parseFloat(qty) * Number.parseFloat(prc)
    setTotal(isNaN(calculatedTotal) ? "0" : calculatedTotal.toFixed(2))
  }

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setQuantity(e.target.value)
    updateTotal(e.target.value, price)
  }

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPrice(e.target.value)
    updateTotal(quantity, e.target.value)
  }

  const checkFunds = (amount: number): boolean => {
    if (accountBalance < amount) {
      setShowInsufficientFunds(true)
      return false
    }
    setShowInsufficientFunds(false)
    return true
  }

  const handleBuy = (e: React.FormEvent) => {
    e.preventDefault()

    const totalAmount = Number.parseFloat(total)
    if (isNaN(totalAmount) || totalAmount <= 0) {
      toast({
        title: "Invalid Order",
        description: "Please enter a valid quantity and price",
        variant: "destructive",
      })
      return
    }

    // Check if user has enough funds
    if (!onTradeExecution(totalAmount)) {
      return
    }

    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)

      toast({
        title: "Order Placed Successfully",
        description: `Bought ${quantity} ${symbol} at ${orderType === "market" ? currentPrice.toFixed(2) : price}`,
      })

      // Reset form
      setQuantity("1")
      setPrice(currentPrice.toString())
      updateTotal("1", currentPrice.toString())
    }, 1500)
  }

  const handleSell = (e: React.FormEvent) => {
    e.preventDefault()

    const totalAmount = Number.parseFloat(total)
    if (isNaN(totalAmount) || totalAmount <= 0) {
      toast({
        title: "Invalid Order",
        description: "Please enter a valid quantity and price",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)

      toast({
        title: "Order Placed Successfully",
        description: `Sold ${quantity} ${symbol} at ${orderType === "market" ? currentPrice.toFixed(2) : price}`,
      })

      // Reset form
      setQuantity("1")
      setPrice(currentPrice.toString())
      updateTotal("1", currentPrice.toString())
    }, 1500)
  }

  return (
    <div className="space-y-4">
      {showInsufficientFunds && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="flex justify-between items-center">
            <span>Insufficient funds for this trade</span>
            <Button
              variant="outline"
              size="sm"
              className="ml-2 border-red-300 text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-300 dark:hover:bg-red-950"
              onClick={onOpenDeposit}
            >
              <DollarSign className="h-3 w-3 mr-1" />
              Deposit
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="buy" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="buy">Buy</TabsTrigger>
          <TabsTrigger value="sell">Sell</TabsTrigger>
        </TabsList>
        <TabsContent value="buy" className="space-y-4 pt-4">
          <form onSubmit={handleBuy}>
            <div className="space-y-2">
              <Label htmlFor="order-type">Order Type</Label>
              <Select defaultValue={orderType} onValueChange={setOrderType}>
                <SelectTrigger id="order-type">
                  <SelectValue placeholder="Select order type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="market">Market</SelectItem>
                  <SelectItem value="limit">Limit</SelectItem>
                  <SelectItem value="stop">Stop</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 mt-4">
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                id="quantity"
                type="number"
                min="0.0001"
                step="0.0001"
                value={quantity}
                onChange={handleQuantityChange}
              />
            </div>

            {orderType !== "market" && (
              <div className="space-y-2 mt-4">
                <Label htmlFor="price">Price</Label>
                <Input id="price" type="number" min="0.01" step="0.01" value={price} onChange={handlePriceChange} />
              </div>
            )}

            <div className="flex justify-between items-center pt-4 mt-2 border-t">
              <span className="text-muted-foreground">Total Cost:</span>
              <span className="font-semibold">${Number.parseFloat(total).toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center pt-2 text-xs">
              <span className="text-muted-foreground">Available Balance:</span>
              <span className={accountBalance < Number.parseFloat(total) ? "text-red-500" : "text-green-500"}>
                ${accountBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            <Button
              type="submit"
              className="w-full mt-4 bg-green-600 hover:bg-green-700"
              disabled={isSubmitting || accountBalance < Number.parseFloat(total)}
              onClick={() => checkFunds(Number.parseFloat(total))}
            >
              {isSubmitting ? "Processing..." : `Buy ${symbol}`}
            </Button>
          </form>
        </TabsContent>
        <TabsContent value="sell" className="space-y-4 pt-4">
          <form onSubmit={handleSell}>
            <div className="space-y-2">
              <Label htmlFor="sell-order-type">Order Type</Label>
              <Select defaultValue={orderType} onValueChange={setOrderType}>
                <SelectTrigger id="sell-order-type">
                  <SelectValue placeholder="Select order type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="market">Market</SelectItem>
                  <SelectItem value="limit">Limit</SelectItem>
                  <SelectItem value="stop">Stop</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 mt-4">
              <Label htmlFor="sell-quantity">Quantity</Label>
              <Input
                id="sell-quantity"
                type="number"
                min="0.0001"
                step="0.0001"
                value={quantity}
                onChange={handleQuantityChange}
              />
            </div>

            {orderType !== "market" && (
              <div className="space-y-2 mt-4">
                <Label htmlFor="sell-price">Price</Label>
                <Input
                  id="sell-price"
                  type="number"
                  min="0.01"
                  step="0.01"
                  value={price}
                  onChange={handlePriceChange}
                />
              </div>
            )}

            <div className="flex justify-between items-center pt-4 mt-2 border-t">
              <span className="text-muted-foreground">Estimated Total:</span>
              <span className="font-semibold">${Number.parseFloat(total).toLocaleString()}</span>
            </div>

            <Button type="submit" className="w-full mt-4 bg-red-600 hover:bg-red-700" disabled={isSubmitting}>
              {isSubmitting ? "Processing..." : `Sell ${symbol}`}
            </Button>
          </form>
        </TabsContent>
      </Tabs>
    </div>
  )
}
