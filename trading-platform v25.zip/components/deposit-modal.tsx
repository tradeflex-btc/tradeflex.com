"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { CreditCard, Wallet, ArrowDownToLine, Copy, Check, Shield, AlertTriangle } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface DepositModalProps {
  open: boolean
  onClose: () => void
  onSuccess: (amount: number) => void
}

export function DepositModal({ open, onClose, onSuccess }: DepositModalProps) {
  const [activeTab, setActiveTab] = useState<"crypto" | "card" | "bank">("crypto")
  const [amount, setAmount] = useState("")
  const [cardNumber, setCardNumber] = useState("")
  const [expiryDate, setExpiryDate] = useState("")
  const [cvv, setCvv] = useState("")
  const [cardholderName, setCardholderName] = useState("")
  const [cryptoAmount, setCryptoAmount] = useState("")
  const [selectedCrypto, setSelectedCrypto] = useState("BTC")
  const [bankName, setBankName] = useState("")
  const [accountNumber, setAccountNumber] = useState("")
  const [routingNumber, setRoutingNumber] = useState("")
  const [accountName, setAccountName] = useState("")
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [showVerification, setShowVerification] = useState(false)
  const [verificationCode, setVerificationCode] = useState("")
  const { toast } = useToast()

  // Reset form when modal opens
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setAmount("")
      setCardNumber("")
      setExpiryDate("")
      setCvv("")
      setCardholderName("")
      setCryptoAmount("")
      setSelectedCrypto("BTC")
      setBankName("")
      setAccountNumber("")
      setRoutingNumber("")
      setAccountName("")
      setShowVerification(false)
      setVerificationCode("")
      onClose()
    }
  }

  // Handle credit card deposit
  const handleCardDeposit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simple validation
    if (!amount || !cardNumber || !expiryDate || !cvv || !cardholderName) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    const depositAmount = Number.parseFloat(amount)
    if (isNaN(depositAmount) || depositAmount <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    // Show verification step
    setShowVerification(true)
    setLoading(false)
  }

  // Handle verification code submission
  const handleVerificationSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simple validation
    if (!verificationCode || verificationCode.length < 6) {
      toast({
        title: "Error",
        description: "Please enter a valid verification code",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    // Simulate API call
    setTimeout(() => {
      setLoading(false)
      const depositAmount = Number.parseFloat(amount)

      // In a real app, you would process the payment through a payment gateway
      toast({
        title: "Deposit Successful",
        description: `$${depositAmount.toFixed(2)} has been added to your account`,
      })

      onSuccess(depositAmount)
      onClose()
    }, 2000)
  }

  // Handle bank transfer deposit
  const handleBankDeposit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simple validation
    if (!amount || !bankName || !accountNumber || !routingNumber || !accountName) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    const depositAmount = Number.parseFloat(amount)
    if (isNaN(depositAmount) || depositAmount <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    // Show verification step
    setShowVerification(true)
    setLoading(false)
  }

  // Handle crypto deposit
  const handleCryptoDeposit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simple validation
    if (!cryptoAmount) {
      toast({
        title: "Error",
        description: "Please enter an amount",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    const depositAmount = Number.parseFloat(cryptoAmount)
    if (isNaN(depositAmount) || depositAmount <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive",
      })
      setLoading(false)
      return
    }

    // In a real app, you would verify the crypto deposit
    toast({
      title: "Deposit Instructions Sent",
      description: `Please send ${depositAmount} ${selectedCrypto} to the provided address`,
    })
    setLoading(false)
  }

  // Handle copy address
  const handleCopyAddress = () => {
    const address = getCryptoAddress(selectedCrypto)
    navigator.clipboard.writeText(address)
    setCopied(true)

    toast({
      title: "Address Copied",
      description: "Wallet address copied to clipboard",
    })

    setTimeout(() => setCopied(false), 2000)
  }

  // Get crypto address based on selected crypto
  const getCryptoAddress = (crypto: string) => {
    switch (crypto) {
      case "BTC":
        return "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh"
      case "ETH":
        return "0x71C7656EC7ab88b098defB751B7401B5f6d8976F"
      case "USDT":
        return "0x8b99F3D124AeD961C5D91B0f7E0B9545D8a0d786"
      default:
        return "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh"
    }
  }

  // Render verification step
  if (showVerification) {
    return (
      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Verify Your Deposit</DialogTitle>
          </DialogHeader>

          <Alert className="mb-4 bg-blue-50 border-blue-200 dark:bg-blue-950 dark:border-blue-800">
            <Shield className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            <AlertTitle className="text-blue-800 dark:text-blue-300">Security Verification</AlertTitle>
            <AlertDescription className="text-blue-700 dark:text-blue-400">
              For your security, we've sent a verification code to your registered email address.
            </AlertDescription>
          </Alert>

          <form onSubmit={handleVerificationSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="verification-code">Verification Code</Label>
              <Input
                id="verification-code"
                placeholder="Enter 6-digit code"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                maxLength={6}
              />
              <p className="text-sm text-muted-foreground">Please enter the 6-digit code sent to your email</p>
            </div>

            <div className="flex justify-between">
              <Button type="button" variant="outline" onClick={() => setShowVerification(false)}>
                Back
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? "Verifying..." : "Confirm Deposit"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Deposit Funds</DialogTitle>
        </DialogHeader>

        <Alert className="mb-4 bg-amber-50 border-amber-200 dark:bg-amber-950 dark:border-amber-800">
          <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          <AlertDescription className="text-amber-700 dark:text-amber-400">
            You are depositing real money. All transactions are final and subject to our terms of service.
          </AlertDescription>
        </Alert>

        <Tabs
          defaultValue="crypto"
          value={activeTab}
          onValueChange={(value) => setActiveTab(value as "crypto" | "card" | "bank")}
        >
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="crypto">Crypto</TabsTrigger>
            <TabsTrigger value="card">Credit Card</TabsTrigger>
            <TabsTrigger value="bank">Bank Transfer</TabsTrigger>
          </TabsList>

          <TabsContent value="crypto" className="space-y-4 pt-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Deposit {selectedCrypto}</CardTitle>
                <CardDescription>Send funds to the following address</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="crypto-select">Select Cryptocurrency</Label>
                    <Select value={selectedCrypto} onValueChange={setSelectedCrypto}>
                      <SelectTrigger id="crypto-select">
                        <SelectValue placeholder="Select cryptocurrency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                        <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                        <SelectItem value="USDT">Tether (USDT)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="crypto-amount">Amount</Label>
                    <div className="flex gap-2">
                      <Input
                        id="crypto-amount"
                        type="number"
                        min="0.00000001"
                        step="0.00000001"
                        placeholder={`Enter ${selectedCrypto} amount`}
                        value={cryptoAmount}
                        onChange={(e) => setCryptoAmount(e.target.value)}
                      />
                      <Button variant="outline" className="w-[100px]">
                        {selectedCrypto}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Wallet Address</Label>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 p-2 border rounded-md bg-muted text-xs font-mono overflow-x-auto">
                        {getCryptoAddress(selectedCrypto)}
                      </div>
                      <Button size="sm" variant="outline" onClick={handleCopyAddress}>
                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div className="pt-2">
                    <Button className="w-full" onClick={handleCryptoDeposit} disabled={loading}>
                      <Wallet className="h-4 w-4 mr-2" />
                      {loading ? "Processing..." : "Confirm Deposit"}
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="px-6 py-3 border-t text-xs text-muted-foreground">
                <p>Crypto deposits typically take 10-60 minutes to confirm</p>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="card" className="space-y-4 pt-4">
            <form onSubmit={handleCardDeposit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="deposit-amount">Amount (USD)</Label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5">$</span>
                  <Input
                    id="deposit-amount"
                    type="number"
                    min="10"
                    step="0.01"
                    placeholder="0.00"
                    className="pl-7"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="card-number">Card Number</Label>
                <Input
                  id="card-number"
                  placeholder="1234 5678 9012 3456"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expiry-date">Expiry Date</Label>
                  <Input
                    id="expiry-date"
                    placeholder="MM/YY"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cvv">CVV</Label>
                  <Input id="cvv" placeholder="123" value={cvv} onChange={(e) => setCvv(e.target.value)} required />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="cardholder-name">Cardholder Name</Label>
                <Input
                  id="cardholder-name"
                  placeholder="John Doe"
                  value={cardholderName}
                  onChange={(e) => setCardholderName(e.target.value)}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                <CreditCard className="h-4 w-4 mr-2" />
                {loading ? "Processing..." : "Continue to Verification"}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="bank" className="space-y-4 pt-4">
            <form onSubmit={handleBankDeposit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="bank-deposit-amount">Amount (USD)</Label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5">$</span>
                  <Input
                    id="bank-deposit-amount"
                    type="number"
                    min="10"
                    step="0.01"
                    placeholder="0.00"
                    className="pl-7"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bank-name">Bank Name</Label>
                <Input
                  id="bank-name"
                  placeholder="Enter your bank name"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="account-number">Account Number</Label>
                <Input
                  id="account-number"
                  placeholder="Enter your account number"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="routing-number">Routing Number</Label>
                <Input
                  id="routing-number"
                  placeholder="Enter your routing number"
                  value={routingNumber}
                  onChange={(e) => setRoutingNumber(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="account-name">Account Holder Name</Label>
                <Input
                  id="account-name"
                  placeholder="Enter account holder name"
                  value={accountName}
                  onChange={(e) => setAccountName(e.target.value)}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                <ArrowDownToLine className="h-4 w-4 mr-2" />
                {loading ? "Processing..." : "Continue to Verification"}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
