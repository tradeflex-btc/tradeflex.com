"use client"

import Link from "next/link"
import { useTheme } from "@/components/theme-provider"

export function Logo() {
  const { theme } = useTheme()

  return (
    <Link href="/" className="flex items-center gap-2">
      <div className="flex items-center justify-center w-8 h-8 rounded-md bg-black text-white font-bold text-lg">
        TF
      </div>
      <span className="font-bold text-xl">
        <span className={theme === "dark" ? "text-white" : "text-black"}>Trade</span>
        <span className={theme === "light" ? "text-black" : "text-white"}>Flex</span>
      </span>
    </Link>
  )
}
