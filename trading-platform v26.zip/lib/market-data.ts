// Types for market data
export interface MarketData {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  high24h?: number
  low24h?: number
  volume24h?: number
  marketCap?: number
  type: "crypto" | "stock"
}

export interface CandleData {
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume?: number
}

export interface TimeSeriesData {
  prices: number[]
  timestamps: number[]
}

// Cache for market data to avoid excessive API calls
const dataCache: Record<string, { data: any; timestamp: number }> = {}
const CACHE_DURATION = 60000 // 1 minute cache

// Flag to track API availability
let coinGeckoAvailable = true
let alphaVantageAvailable = true
let lastCoinGeckoAttempt = 0
let lastAlphaVantageAttempt = 0
const API_RETRY_INTERVAL = 60000 // 1 minute before retrying after failure

// Helper function to check if data is cached and still valid
function getCachedData(key: string) {
  const cached = dataCache[key]
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.data
  }
  return null
}

// Helper function to cache data
function cacheData(key: string, data: any) {
  dataCache[key] = { data, timestamp: Date.now() }
  return data
}

// Check if we should try an API or use mock data
function shouldUseAPI(apiName: "coingecko" | "alphavantage"): boolean {
  const now = Date.now()
  if (apiName === "coingecko") {
    // If API was unavailable, only retry after the retry interval
    if (!coinGeckoAvailable && now - lastCoinGeckoAttempt < API_RETRY_INTERVAL) {
      return false
    }
    // Update last attempt time and return true to try the API
    lastCoinGeckoAttempt = now
    return true
  } else {
    // Alpha Vantage
    if (!alphaVantageAvailable && now - lastAlphaVantageAttempt < API_RETRY_INTERVAL) {
      return false
    }
    lastAlphaVantageAttempt = now
    return true
  }
}

// Convert timeframe to milliseconds
export function timeFrameToMs(timeFrame: string): number {
  switch (timeFrame) {
    case "live":
      return 1000
    case "1m":
      return 60 * 1000
    case "5m":
      return 5 * 60 * 1000
    case "15m":
      return 15 * 60 * 1000
    case "30m":
      return 30 * 60 * 1000
    case "1h":
      return 60 * 60 * 1000
    case "4h":
      return 4 * 60 * 60 * 1000
    case "1d":
      return 24 * 60 * 60 * 1000
    default:
      return 60 * 60 * 1000
  }
}

// Convert timeframe to days for API calls
function timeFrameToDays(timeFrame: string): number {
  switch (timeFrame) {
    case "live":
      return 1
    case "1m":
      return 1
    case "5m":
      return 1
    case "15m":
      return 1
    case "30m":
      return 1
    case "1h":
      return 2
    case "4h":
      return 7
    case "1d":
      return 30
    default:
      return 7
  }
}

// Convert timeframe to interval for API calls
function timeFrameToInterval(timeFrame: string): string {
  switch (timeFrame) {
    case "live":
      return "1m"
    case "1m":
      return "1m"
    case "5m":
      return "5m"
    case "15m":
      return "15m"
    case "30m":
      return "30m"
    case "1h":
      return "1h"
    case "4h":
      return "4h"
    case "1d":
      return "1d"
    default:
      return "1h"
  }
}

// Get cryptocurrency ID for CoinGecko API
function getCryptoId(symbol: string): string {
  // Clean up the symbol first
  const cleanSymbol = symbol.replace("/USD", "").replace("-USD", "").toUpperCase()

  const symbolMap: Record<string, string> = {
    BTC: "bitcoin",
    ETH: "ethereum",
    SOL: "solana",
    "BTC/USD": "bitcoin",
    "ETH/USD": "ethereum",
    "SOL/USD": "solana",
    DOGE: "dogecoin",
    XRP: "ripple",
    ADA: "cardano",
    DOT: "polkadot",
    LINK: "chainlink",
    LTC: "litecoin",
    BCH: "bitcoin-cash",
    XLM: "stellar",
    UNI: "uniswap",
    AAVE: "aave",
  }

  // Try to find the symbol in our map
  if (symbolMap[cleanSymbol]) {
    return symbolMap[cleanSymbol]
  }

  // If not found, try to convert it to a format that might work with CoinGecko
  return cleanSymbol.toLowerCase()
}

// Get stock symbol for Alpha Vantage API
function getStockSymbol(symbol: string): string {
  return symbol.replace("/USD", "").replace("-USD", "")
}

// Helper function to validate API response
function isValidResponse(data: any): boolean {
  return (
    data !== null && typeof data === "object" && !Array.isArray(data) && Object.keys(data).length > 0 && !data.error
  )
}

// Fetch market overview data (current prices, 24h changes)
export async function fetchMarketOverview(): Promise<MarketData[]> {
  const cacheKey = "market-overview"
  const cached = getCachedData(cacheKey)
  if (cached) return cached

  try {
    // Fetch cryptocurrency data
    let cryptoMarketData: MarketData[] = []

    if (shouldUseAPI("coingecko")) {
      try {
        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

        const cryptoResponse = await fetch(
          "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=bitcoin,ethereum,solana&order=market_cap_desc&sparkline=false",
          { signal: controller.signal },
        )

        clearTimeout(timeoutId)

        if (cryptoResponse.ok) {
          const cryptoData = await cryptoResponse.json()
          coinGeckoAvailable = true // Mark API as available

          // Format cryptocurrency data
          if (Array.isArray(cryptoData) && cryptoData.length > 0) {
            cryptoMarketData = cryptoData.map((crypto: any) => ({
              symbol: `${crypto.symbol?.toUpperCase() || "UNKNOWN"}/USD`,
              name: crypto.name || "Unknown",
              price: typeof crypto.current_price === "number" ? crypto.current_price : 0,
              change: typeof crypto.price_change_24h === "number" ? crypto.price_change_24h : 0,
              changePercent:
                typeof crypto.price_change_percentage_24h === "number" ? crypto.price_change_percentage_24h : 0,
              high24h: crypto.high_24h,
              low24h: crypto.low_24h,
              volume24h: crypto.total_volume,
              marketCap: crypto.market_cap,
              type: "crypto" as const,
            }))
          } else {
            throw new Error("Invalid data format from CoinGecko API")
          }
        } else {
          console.warn(`CoinGecko API error: ${cryptoResponse.status} ${cryptoResponse.statusText}`)
          coinGeckoAvailable = false // Mark API as unavailable
          throw new Error(`CoinGecko API returned status ${cryptoResponse.status}`)
        }
      } catch (error) {
        console.warn("Error fetching cryptocurrency data:", error)
        coinGeckoAvailable = false // Mark API as unavailable

        // Use mock crypto data
        cryptoMarketData = getMockCryptoData()
      }
    } else {
      // Skip CoinGecko API and use mock data directly
      console.log("Using mock crypto data due to previous API failures")
      cryptoMarketData = getMockCryptoData()
    }

    // Fetch stock data (using Alpha Vantage API)
    let stockMarketData: MarketData[] = []

    if (shouldUseAPI("alphavantage")) {
      try {
        const stockSymbols = ["AAPL", "MSFT", "GOOGL"]
        const stockDataPromises = stockSymbols.map(async (symbol) => {
          try {
            const controller = new AbortController()
            const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

            const response = await fetch(
              `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=demo`,
              { signal: controller.signal },
            )

            clearTimeout(timeoutId)

            if (!response.ok) {
              throw new Error(`Alpha Vantage API error: ${response.status} ${response.statusText}`)
            }

            const data = await response.json()

            // Check if the response has the expected structure
            if (!data || !data["Global Quote"] || !data["Global Quote"]["01. symbol"]) {
              throw new Error("Invalid response format from Alpha Vantage API")
            }

            return data
          } catch (error) {
            console.warn(`Error fetching stock data for ${symbol}:`, error)
            // Return mock data if API fails
            return getMockStockData(symbol)
          }
        })

        const stockDataResults = await Promise.all(stockDataPromises)
        alphaVantageAvailable = true // Mark API as available

        // Format stock data
        stockMarketData = stockDataResults.map((stockData: any) => {
          // Check if we're dealing with mock data or real API data
          if (stockData.isMockData) {
            return stockData
          }

          const quote = stockData["Global Quote"]
          if (!quote || !quote["01. symbol"]) {
            // If the structure is invalid, return mock data
            const symbol = stockData.symbol || "UNKNOWN"
            return getMockStockData(symbol)
          }

          try {
            return {
              symbol: quote["01. symbol"],
              name: getStockName(quote["01. symbol"]),
              price: Number.parseFloat(quote["05. price"]) || 0,
              change: Number.parseFloat(quote["09. change"]) || 0,
              changePercent: Number.parseFloat(quote["10. change percent"]?.replace("%", "")) || 0,
              type: "stock" as const,
            }
          } catch (error) {
            console.warn(`Error parsing stock data for ${quote["01. symbol"]}:`, error)
            return getMockStockData(quote["01. symbol"])
          }
        })
      } catch (error) {
        console.warn("Error processing stock data:", error)
        alphaVantageAvailable = false // Mark API as unavailable
        // Use mock stock data
        stockMarketData = getMockStockData()
      }
    } else {
      // Skip Alpha Vantage API and use mock data directly
      console.log("Using mock stock data due to previous API failures")
      stockMarketData = getMockStockData()
    }

    // Combine and cache the data
    const marketData = [...cryptoMarketData, ...stockMarketData]
    return cacheData(cacheKey, marketData)
  } catch (error) {
    console.error("Error fetching market overview:", error)
    // Return mock data if API fails
    return [...getMockCryptoData(), ...getMockStockData()]
  }
}

// Helper function to get mock crypto data
function getMockCryptoData(): MarketData[] {
  return [
    { symbol: "BTC/USD", name: "Bitcoin", price: 84823.0, change: 786.32, changePercent: 1.24, type: "crypto" },
    { symbol: "ETH/USD", name: "Ethereum", price: 3482.5, change: 74.87, changePercent: 2.15, type: "crypto" },
    { symbol: "SOL/USD", name: "Solana", price: 142.75, change: -1.24, changePercent: -0.87, type: "crypto" },
  ]
}

// Helper function to get mock stock data
function getMockStockData(symbol?: string): MarketData | MarketData[] {
  const mockStocks = [
    {
      symbol: "AAPL",
      name: "Apple Inc.",
      price: 175.25,
      change: 0.78,
      changePercent: 0.45,
      type: "stock" as const,
      isMockData: true,
    },
    {
      symbol: "MSFT",
      name: "Microsoft",
      price: 415.75,
      change: 4.65,
      changePercent: 1.12,
      type: "stock" as const,
      isMockData: true,
    },
    {
      symbol: "GOOGL",
      name: "Alphabet",
      price: 172.5,
      change: -0.55,
      changePercent: -0.32,
      type: "stock" as const,
      isMockData: true,
    },
  ]

  if (symbol) {
    const mockStock = mockStocks.find((stock) => stock.symbol === symbol)
    if (mockStock) {
      return mockStock
    }
    // If symbol not found in our mock data, create a generic one
    return {
      symbol,
      name: getStockName(symbol),
      price: 100,
      change: 0,
      changePercent: 0,
      type: "stock" as const,
      isMockData: true,
    }
  }

  return mockStocks
}

// Helper function to get stock names
function getStockName(symbol: string): string {
  const stockNames: Record<string, string> = {
    AAPL: "Apple Inc.",
    MSFT: "Microsoft",
    GOOGL: "Alphabet",
    AMZN: "Amazon",
    META: "Meta Platforms",
    TSLA: "Tesla",
    NVDA: "NVIDIA",
  }
  return stockNames[symbol] || symbol
}

// Fetch historical price data for a specific asset and timeframe
export async function fetchHistoricalData(symbol: string, timeFrame: string): Promise<TimeSeriesData> {
  const cacheKey = `historical-${symbol}-${timeFrame}`
  const cached = getCachedData(cacheKey)
  if (cached) return cached

  try {
    let prices: number[] = []
    let timestamps: number[] = []

    if (symbol.includes("/USD") || symbol.includes("BTC") || symbol.includes("ETH") || symbol.includes("SOL")) {
      // Handle cryptocurrency data
      if (shouldUseAPI("coingecko")) {
        try {
          const cryptoId = getCryptoId(symbol)
          const days = timeFrameToDays(timeFrame)
          const interval = timeFrameToInterval(timeFrame)

          const controller = new AbortController()
          const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

          const response = await fetch(
            `https://api.coingecko.com/api/v3/coins/${cryptoId}/market_chart?vs_currency=usd&days=${days}&interval=${interval}`,
            { signal: controller.signal },
          )

          clearTimeout(timeoutId)

          if (!response.ok) {
            console.warn(`CoinGecko API error for ${symbol}: ${response.status} ${response.statusText}`)
            coinGeckoAvailable = false // Mark API as unavailable
            throw new Error(`CoinGecko API returned status ${response.status}`)
          }

          const data = await response.json()
          coinGeckoAvailable = true // Mark API as available

          // Check if data.prices exists and is an array before mapping
          if (data && data.prices && Array.isArray(data.prices) && data.prices.length > 0) {
            // Extract prices and timestamps
            prices = data.prices.map((item: [number, number]) => item[1])
            timestamps = data.prices.map((item: [number, number]) => item[0])
          } else {
            console.warn("Invalid data format received from CoinGecko API:", data)
            throw new Error("Invalid data format from CoinGecko API")
          }
        } catch (error) {
          console.warn(`Error fetching data from CoinGecko for ${symbol}:`, error)
          return generateMockHistoricalData(symbol, timeFrame)
        }
      } else {
        // Skip CoinGecko API and use mock data directly
        console.log(`Using mock data for ${symbol} due to previous API failures`)
        return generateMockHistoricalData(symbol, timeFrame)
      }
    } else {
      // Handle stock data
      if (shouldUseAPI("alphavantage")) {
        try {
          const stockSymbol = getStockSymbol(symbol)

          // Map timeframe to Alpha Vantage interval
          let avInterval = "60min" // default
          if (timeFrame === "1d") avInterval = "daily"
          else if (timeFrame === "1m" || timeFrame === "5m" || timeFrame === "15m" || timeFrame === "30m")
            avInterval = "5min"
          else if (timeFrame === "1h") avInterval = "60min"
          else if (timeFrame === "4h") avInterval = "60min"

          let function_name = "TIME_SERIES_INTRADAY"
          if (avInterval === "daily") function_name = "TIME_SERIES_DAILY"

          const controller = new AbortController()
          const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

          const response = await fetch(
            `https://www.alphavantage.co/query?function=${function_name}&symbol=${stockSymbol}&interval=${avInterval}&apikey=demo`,
            { signal: controller.signal },
          )

          clearTimeout(timeoutId)

          if (!response.ok) {
            console.warn(`Alpha Vantage API error for ${symbol}: ${response.status} ${response.statusText}`)
            alphaVantageAvailable = false // Mark API as unavailable
            throw new Error(`Alpha Vantage API returned status ${response.status}`)
          }

          const data = await response.json()
          alphaVantageAvailable = true // Mark API as available

          // Extract data based on the function used
          const timeSeriesKey =
            function_name === "TIME_SERIES_DAILY" ? "Time Series (Daily)" : `Time Series (${avInterval})`

          const timeSeries = data[timeSeriesKey]

          if (timeSeries && Object.keys(timeSeries).length > 0) {
            // Convert object to array and sort by date
            const timeSeriesArray = Object.entries(timeSeries)
              .map(([date, values]: [string, any]) => {
                try {
                  return {
                    timestamp: new Date(date).getTime(),
                    close: Number.parseFloat(values["4. close"]) || 0,
                  }
                } catch (error) {
                  console.warn(`Error parsing time series data for ${date}:`, error)
                  return null
                }
              })
              .filter((item) => item !== null) // Remove any null items
              .sort((a, b) => a!.timestamp - b!.timestamp)

            if (timeSeriesArray.length === 0) {
              throw new Error("No valid data points found in Alpha Vantage response")
            }

            // Extract prices and timestamps
            prices = timeSeriesArray.map((item) => item!.close)
            timestamps = timeSeriesArray.map((item) => item!.timestamp)

            // For 4h timeframe, sample every 4 data points from 1h data
            if (timeFrame === "4h" && avInterval === "60min") {
              const sampledData = []
              for (let i = 0; i < prices.length; i += 4) {
                sampledData.push({
                  price: prices[i],
                  timestamp: timestamps[i],
                })
              }
              prices = sampledData.map((item) => item.price)
              timestamps = sampledData.map((item) => item.timestamp)
            }
          } else {
            console.warn("Invalid data format received from Alpha Vantage API:", data)
            throw new Error("Invalid data format from Alpha Vantage API")
          }
        } catch (error) {
          console.warn(`Error fetching historical data for ${symbol} from Alpha Vantage:`, error)
          alphaVantageAvailable = false // Mark API as unavailable
          return generateMockHistoricalData(symbol, timeFrame)
        }
      } else {
        // Skip Alpha Vantage API and use mock data directly
        console.log(`Using mock data for ${symbol} due to previous API failures`)
        return generateMockHistoricalData(symbol, timeFrame)
      }
    }

    // If we get here but have no data, generate mock data
    if (prices.length === 0 || timestamps.length === 0) {
      console.warn(`No data returned for ${symbol} with timeframe ${timeFrame}, using mock data instead.`)
      return generateMockHistoricalData(symbol, timeFrame)
    }

    return cacheData(cacheKey, { prices, timestamps })
  } catch (error) {
    console.error(`Error fetching historical data for ${symbol}:`, error)
    // Return mock data if API fails
    return generateMockHistoricalData(symbol, timeFrame)
  }
}

// Fetch candle data for a specific asset and timeframe
export async function fetchCandleData(symbol: string, timeFrame: string): Promise<CandleData[]> {
  const cacheKey = `candle-${symbol}-${timeFrame}`
  const cached = getCachedData(cacheKey)
  if (cached) return cached

  try {
    let candleData: CandleData[] = []

    if (symbol.includes("/USD") || symbol.includes("BTC") || symbol.includes("ETH") || symbol.includes("SOL")) {
      // Handle cryptocurrency data
      if (shouldUseAPI("coingecko")) {
        try {
          const cryptoId = getCryptoId(symbol)
          const days = timeFrameToDays(timeFrame)

          // CoinGecko doesn't provide OHLC for all intervals, so we need to adjust
          let ohlcDays = days
          if (timeFrame === "1m" || timeFrame === "5m" || timeFrame === "15m" || timeFrame === "30m") {
            ohlcDays = 1 // Max 1 day for hourly OHLC data
          }

          const controller = new AbortController()
          const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

          const response = await fetch(
            `https://api.coingecko.com/api/v3/coins/${cryptoId}/ohlc?vs_currency=usd&days=${ohlcDays}`,
            { signal: controller.signal },
          )

          clearTimeout(timeoutId)

          if (!response.ok) {
            console.warn(`CoinGecko API error for ${symbol}: ${response.status} ${response.statusText}`)
            coinGeckoAvailable = false // Mark API as unavailable
            throw new Error(`CoinGecko API returned status ${response.status}`)
          }

          const data = await response.json()
          coinGeckoAvailable = true // Mark API as available

          // Check if data is an array before mapping
          if (data && Array.isArray(data) && data.length > 0) {
            // Format the OHLC data
            candleData = data.map((item: [number, number, number, number, number]) => ({
              timestamp: item[0],
              open: item[1],
              high: item[2],
              low: item[3],
              close: item[4],
            }))

            // Filter data based on timeframe
            const interval = timeFrameToMs(timeFrame)
            if (interval > 0 && interval !== timeFrameToMs("1d")) {
              // Sample data at the appropriate interval
              const filteredData: CandleData[] = []
              let lastTimestamp = 0

              for (const candle of candleData) {
                if (lastTimestamp === 0 || candle.timestamp - lastTimestamp >= interval) {
                  filteredData.push(candle)
                  lastTimestamp = candle.timestamp
                }
              }

              candleData = filteredData
            }
          } else {
            console.warn("Invalid OHLC data format received from CoinGecko API:", data)
            throw new Error("Invalid OHLC data format from CoinGecko API")
          }
        } catch (error) {
          console.warn(`Failed to fetch candle data for ${symbol} from CoinGecko:`, error)
          coinGeckoAvailable = false // Mark API as unavailable
          return generateMockCandleData(symbol, timeFrame)
        }
      } else {
        // Skip CoinGecko API and use mock data directly
        console.log(`Using mock candle data for ${symbol} due to previous API failures`)
        return generateMockCandleData(symbol, timeFrame)
      }
    } else {
      // Handle stock data
      if (shouldUseAPI("alphavantage")) {
        try {
          const stockSymbol = getStockSymbol(symbol)

          // Map timeframe to Alpha Vantage interval
          let avInterval = "60min" // default
          if (timeFrame === "1d") avInterval = "daily"
          else if (timeFrame === "1m" || timeFrame === "5m") avInterval = "5min"
          else if (timeFrame === "15m" || timeFrame === "30m") avInterval = "30min"
          else if (timeFrame === "1h") avInterval = "60min"

          let function_name = "TIME_SERIES_INTRADAY"
          if (avInterval === "daily") function_name = "TIME_SERIES_DAILY"

          const controller = new AbortController()
          const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

          const response = await fetch(
            `https://www.alphavantage.co/query?function=${function_name}&symbol=${stockSymbol}&interval=${avInterval}&outputsize=compact&apikey=demo`,
            { signal: controller.signal },
          )

          clearTimeout(timeoutId)

          if (!response.ok) {
            console.warn(`Alpha Vantage API error for ${symbol}: ${response.status} ${response.statusText}`)
            alphaVantageAvailable = false // Mark API as unavailable
            throw new Error(`Alpha Vantage API returned status ${response.status}`)
          }

          const data = await response.json()
          alphaVantageAvailable = true // Mark API as available

          // Extract data based on the function used
          const timeSeriesKey =
            function_name === "TIME_SERIES_DAILY" ? "Time Series (Daily)" : `Time Series (${avInterval})`

          const timeSeries = data[timeSeriesKey]

          if (timeSeries && Object.keys(timeSeries).length > 0) {
            // Convert object to array and sort by date
            candleData = Object.entries(timeSeries)
              .map(([date, values]: [string, any]) => {
                try {
                  return {
                    timestamp: new Date(date).getTime(),
                    open: Number.parseFloat(values["1. open"]) || 0,
                    high: Number.parseFloat(values["2. high"]) || 0,
                    low: Number.parseFloat(values["3. low"]) || 0,
                    close: Number.parseFloat(values["4. close"]) || 0,
                    volume: Number.parseFloat(values["5. volume"]) || 0,
                  }
                } catch (error) {
                  console.warn(`Error parsing candle data for ${date}:`, error)
                  return null
                }
              })
              .filter((item) => item !== null) // Remove any null items
              .sort((a, b) => a!.timestamp - b!.timestamp) as CandleData[]

            if (candleData.length === 0) {
              throw new Error("No valid candle data points found in Alpha Vantage response")
            }

            // For 4h timeframe, sample every 4 data points from 1h data
            if (timeFrame === "4h" && avInterval === "60min") {
              const sampledData: CandleData[] = []
              for (let i = 0; i < candleData.length; i += 4) {
                if (i + 3 < candleData.length) {
                  sampledData.push({
                    timestamp: candleData[i].timestamp,
                    open: candleData[i].open,
                    high: Math.max(
                      candleData[i].high,
                      candleData[i + 1].high,
                      candleData[i + 2].high,
                      candleData[i + 3].high,
                    ),
                    low: Math.min(
                      candleData[i].low,
                      candleData[i + 1].low,
                      candleData[i + 2].low,
                      candleData[i + 3].low,
                    ),
                    close: candleData[i + 3].close,
                    volume:
                      (candleData[i].volume || 0) +
                      (candleData[i + 1].volume || 0) +
                      (candleData[i + 2].volume || 0) +
                      (candleData[i + 3].volume || 0),
                  })
                }
              }
              candleData = sampledData
            }
          } else {
            console.warn("Invalid data format received from Alpha Vantage API:", data)
            throw new Error("Invalid data format from Alpha Vantage API")
          }
        } catch (error) {
          console.warn(`Failed to fetch candle data for ${symbol} from Alpha Vantage:`, error)
          alphaVantageAvailable = false // Mark API as unavailable
          return generateMockCandleData(symbol, timeFrame)
        }
      } else {
        // Skip Alpha Vantage API and use mock data directly
        console.log(`Using mock candle data for ${symbol} due to previous API failures`)
        return generateMockCandleData(symbol, timeFrame)
      }
    }

    // If API returns no data, generate mock data
    if (candleData.length === 0) {
      return generateMockCandleData(symbol, timeFrame)
    }

    return cacheData(cacheKey, candleData)
  } catch (error) {
    console.error(`Error fetching candle data for ${symbol}:`, error)
    // Return mock data if API fails
    return generateMockCandleData(symbol, timeFrame)
  }
}

// Generate mock historical data if API fails
function generateMockHistoricalData(symbol: string, timeFrame: string): TimeSeriesData {
  const dataPoints = getDataPointsForTimeFrame(timeFrame)
  const basePrice = getBasePriceForSymbol(symbol)
  const volatility = getVolatilityForTimeFrame(timeFrame)
  const interval = timeFrameToMs(timeFrame)

  const now = Date.now()
  const prices: number[] = []
  const timestamps: number[] = []

  let price = basePrice

  // Create a more realistic price trend
  // For Bitcoin, create a pattern that resembles recent BTC price movements
  if (symbol.includes("BTC")) {
    // Start with a slight uptrend
    let trendDirection = 0.0001
    let trendStrength = 0.0001
    let trendCycle = 0

    for (let i = 0; i < dataPoints; i++) {
      // Gradually change trend direction and strength to create realistic patterns
      if (i % 15 === 0) {
        trendCycle++
        // Alternate between uptrends and downtrends
        trendDirection = trendCycle % 3 === 0 ? -0.0002 : 0.0002
        trendStrength = 0.0001 + Math.random() * 0.0003
      }

      // Add some randomness but follow the trend
      const randomFactor = Math.random() * volatility * 2 - volatility
      const trendFactor = trendDirection * trendStrength * i
      price = price * (1 + randomFactor + trendFactor)

      // Add occasional small spikes or dips (market reactions)
      if (Math.random() < 0.03) {
        price = price * (1 + (Math.random() * 0.005 - 0.0025))
      }

      prices.push(price)
      timestamps.push(now - (dataPoints - i) * interval)
    }
  }
  // For other assets, create appropriate patterns
  else {
    // Create a random walk with slight mean reversion
    let momentum = 0
    const meanReversionStrength = 0.2

    for (let i = 0; i < dataPoints; i++) {
      // Random component
      const randomChange = Math.random() * volatility * 2 - volatility

      // Mean reversion component (pull back toward base price)
      const deviation = price / basePrice - 1
      const meanReversion = -deviation * meanReversionStrength * volatility

      // Momentum component (trends tend to continue)
      momentum = momentum * 0.9 + randomChange * 0.1

      // Combine all factors
      const change = randomChange + meanReversion + momentum
      price = price * (1 + change)

      prices.push(price)
      timestamps.push(now - (dataPoints - i) * interval)
    }
  }

  return { prices, timestamps }
}

// Improve the generateMockCandleData function for more realistic candles
function generateMockCandleData(symbol: string, timeFrame: string): CandleData[] {
  const dataPoints = getDataPointsForTimeFrame(timeFrame) / 2 // Fewer candles than line data points
  const basePrice = getBasePriceForSymbol(symbol)
  const volatility = getVolatilityForTimeFrame(timeFrame)
  const interval = timeFrameToMs(timeFrame)

  const now = Date.now()
  const candleData: CandleData[] = []

  let price = basePrice
  const trend = 0 // Track the trend direction

  // For Bitcoin, create a pattern that resembles recent BTC price movements
  if (symbol.includes("BTC")) {
    let trendDirection = 0.0001
    let trendStrength = 0.0001
    let trendCycle = 0

    for (let i = 0; i < dataPoints; i++) {
      // Gradually change trend direction and strength
      if (i % 8 === 0) {
        trendCycle++
        trendDirection = trendCycle % 3 === 0 ? -0.0002 : 0.0002
        trendStrength = 0.0001 + Math.random() * 0.0003
      }

      const open = price

      // Calculate close price with trend and randomness
      const trendFactor = trendDirection * trendStrength * i
      const randomFactor = Math.random() * volatility * 2 - volatility
      const movement = randomFactor + trendFactor
      const close = open * (1 + movement)

      // Calculate high and low with more realistic ranges
      // High and low should extend beyond open/close but be reasonable
      const candleBody = Math.abs(close - open)
      const wickFactor = 0.5 + Math.random() * 1.5 // Random wick length factor

      let high, low
      if (close > open) {
        high = close + candleBody * wickFactor * Math.random()
        low = open - candleBody * wickFactor * Math.random()
      } else {
        high = open + candleBody * wickFactor * Math.random()
        low = close - candleBody * wickFactor * Math.random()
      }

      // Ensure minimum candle size for visibility
      if (high - low < open * 0.001) {
        high = Math.max(open, close) * 1.001
        low = Math.min(open, close) * 0.999
      }

      candleData.push({
        timestamp: now - (dataPoints - i) * interval,
        open,
        high,
        low,
        close,
        volume: Math.floor(Math.random() * 1000000 * (1 + Math.abs(movement) * 10)), // Higher volume on bigger moves
      })

      price = close
    }
  }
  // For other assets
  else {
    let momentum = 0

    for (let i = 0; i < dataPoints; i++) {
      const open = price

      // Random movement with momentum
      const randomChange = Math.random() * volatility * 2 - volatility
      momentum = momentum * 0.8 + randomChange * 0.2
      const movement = randomChange + momentum

      const close = open * (1 + movement)

      // Calculate high and low
      const candleBody = Math.abs(close - open)
      const wickFactor = 0.5 + Math.random() * 1.5

      let high, low
      if (close > open) {
        high = close + candleBody * wickFactor * Math.random()
        low = open - candleBody * wickFactor * Math.random()
      } else {
        high = open + candleBody * wickFactor * Math.random()
        low = close - candleBody * wickFactor * Math.random()
      }

      // Ensure minimum candle size
      if (high - low < open * 0.001) {
        high = Math.max(open, close) * 1.001
        low = Math.min(open, close) * 0.999
      }

      candleData.push({
        timestamp: now - (dataPoints - i) * interval,
        open,
        high,
        low,
        close,
        volume: Math.floor(Math.random() * 1000000 * (1 + Math.abs(movement) * 10)),
      })

      price = close
    }
  }

  return candleData
}

// Update the volatility values for more realistic price movements
function getVolatilityForTimeFrame(timeFrame: string): number {
  switch (timeFrame) {
    case "live":
      return 0.0005
    case "1m":
      return 0.0008
    case "5m":
      return 0.001
    case "15m":
      return 0.0015
    case "30m":
      return 0.002
    case "1h":
      return 0.0025
    case "4h":
      return 0.003
    case "1d":
      return 0.004
    default:
      return 0.001
  }
}

// Helper function to get base price for a symbol
export function getBasePriceForSymbol(symbol: string): number {
  if (symbol.includes("BTC")) return 84823.0
  if (symbol.includes("ETH")) return 3500
  if (symbol.includes("SOL")) return 143
  if (symbol === "AAPL") return 175
  if (symbol === "MSFT") return 415
  if (symbol === "GOOGL") return 172
  return 100
}

// Helper function to get volatility for a timeframe
function getVolatilityForTimeFrame2(timeFrame: string): number {
  switch (timeFrame) {
    case "live":
      return 0.005
    case "1m":
      return 0.008
    case "5m":
      return 0.01
    case "15m":
      return 0.015
    case "30m":
      return 0.02
    case "1h":
      return 0.025
    case "4h":
      return 0.03
    case "1d":
      return 0.04
    default:
      return 0.01
  }
}

// Helper function to get number of data points for a timeframe
function getDataPointsForTimeFrame(timeFrame: string): number {
  switch (timeFrame) {
    case "live":
      return 60
    case "1m":
      return 100
    case "5m":
      return 90
    case "15m":
      return 80
    case "30m":
      return 70
    case "1h":
      return 60
    case "4h":
      return 50
    case "1d":
      return 30
    default:
      return 100
  }
}

// Get current price for a symbol
export async function getCurrentPrice(symbol: string): Promise<number> {
  try {
    const marketData = await fetchMarketOverview()
    const asset = marketData.find((item) => item.symbol === symbol)
    return asset ? asset.price : getBasePriceForSymbol(symbol)
  } catch (error) {
    console.error(`Error getting current price for ${symbol}:`, error)
    return getBasePriceForSymbol(symbol)
  }
}
