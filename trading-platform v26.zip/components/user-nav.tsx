"use client"

import { useState, useEffect } from "react"
import { CreditCard, LogOut, Mail, Settings, User } from "lucide-react"

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { ProfileModal } from "@/components/profile-modal"

interface UserNavProps {
  isLoggedIn: boolean
  username: string
  accountBalance: number
  profilePicture: string | null
  onBalanceUpdate: (newBalance: number) => void
  onSignOut: () => void
  onOpenAuth: (mode: "signin" | "signup") => void
  onProfileUpdate: (data: { username?: string; profilePicture?: string }) => void
}

export function UserNav({
  isLoggedIn,
  username,
  accountBalance,
  profilePicture,
  onBalanceUpdate,
  onSignOut,
  onOpenAuth,
  onProfileUpdate,
}: UserNavProps) {
  const { toast } = useToast()
  const [lastLoginDate, setLastLoginDate] = useState<string | null>(null)
  const [showVerificationReminder, setShowVerificationReminder] = useState(false)
  const [profileModalOpen, setProfileModalOpen] = useState(false)

  // Remove the local profilePicture state since we're now getting it from props

  // Get user initials for avatar fallback
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part.charAt(0))
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  // Update the useEffect to not set profilePicture locally
  useEffect(() => {
    // Check if user should be logged in from localStorage (persistent login)
    const storedUsername = localStorage.getItem("username")

    if (storedUsername && !isLoggedIn) {
      // Auto-login the user if they have a stored session
      const lastActivity = localStorage.getItem("lastActivityTime")
      const now = new Date().getTime()
      const twoWeeksInMs = 14 * 24 * 60 * 60 * 1000 // 2 weeks in milliseconds

      if (lastActivity && now - Number.parseInt(lastActivity) > twoWeeksInMs) {
        // If it's been more than 2 weeks, show verification reminder but keep them logged in
        setShowVerificationReminder(true)
        toast({
          title: "Account Verification Required",
          description: "It's been a while since your last visit. Please verify your account for security.",
          duration: 5000,
        })
      }

      // Update last activity time
      localStorage.setItem("lastActivityTime", now.toString())
    }

    // Check last login date for verification reminder
    if (isLoggedIn) {
      const storedLastLogin = localStorage.getItem("lastLoginDate")
      setLastLoginDate(storedLastLogin)

      // Update last login date to now
      const now = new Date().toISOString()
      localStorage.setItem("lastLoginDate", now)
      localStorage.setItem("lastActivityTime", new Date().getTime().toString())

      // Check if we need to show verification reminder
      if (storedLastLogin) {
        const lastLogin = new Date(storedLastLogin)
        const twoWeeksAgo = new Date()
        twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14)

        if (lastLogin < twoWeeksAgo) {
          setShowVerificationReminder(true)
          toast({
            title: "Account Verification Required",
            description: "It's been over 2 weeks since your last login. Please verify your account through Gmail.",
            duration: 5000,
          })
        }
      }
    }
  }, [isLoggedIn, toast])

  // Handle verification
  const handleVerifyAccount = () => {
    // In a real app, this would send a verification email
    toast({
      title: "Verification Email Sent",
      description: "Please check your Gmail inbox to verify your account.",
    })
    setShowVerificationReminder(false)
  }

  // Update the handleProfileUpdate function to use the prop
  const handleProfileUpdate = (data: { username: string; profilePicture?: string }) => {
    onProfileUpdate(data)
  }

  if (!isLoggedIn) {
    return (
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={() => onOpenAuth("signin")}>
          Sign In
        </Button>
        <Button onClick={() => onOpenAuth("signup")}>Sign Up</Button>
      </div>
    )
  }

  return (
    <div className="flex items-center gap-4">
      {showVerificationReminder && (
        <Button
          variant="outline"
          size="sm"
          className="text-yellow-600 border-yellow-600 hover:bg-yellow-50 dark:hover:bg-yellow-950"
          onClick={handleVerifyAccount}
        >
          <Mail className="mr-2 h-4 w-4" />
          Verify Account
        </Button>
      )}

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-8 w-8 rounded-full">
            <Avatar className="h-8 w-8">
              <AvatarImage src={profilePicture || "/placeholder.svg?height=32&width=32"} alt={username} />
              <AvatarFallback>{getInitials(username)}</AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56" align="end" forceMount>
          <DropdownMenuLabel className="font-normal">
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-medium leading-none">{username}</p>
              <p className="text-xs leading-none text-muted-foreground">
                {username.toLowerCase().replace(/\s+/g, "")}@example.com
              </p>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuGroup>
            <DropdownMenuItem onClick={() => setProfileModalOpen(true)}>
              <User className="mr-2 h-4 w-4" />
              <span>Profile</span>
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => {
                setProfileModalOpen(true)
                // Set billing tab active after a short delay to allow modal to open
                setTimeout(() => {
                  const billingTab = document.querySelector('[value="billing"]') as HTMLElement
                  if (billingTab) billingTab.click()
                }, 100)
              }}
            >
              <CreditCard className="mr-2 h-4 w-4" />
              <span>Billing</span>
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => {
                setProfileModalOpen(true)
                // Set preferences tab active after a short delay
                setTimeout(() => {
                  const preferencesTab = document.querySelector('[value="preferences"]') as HTMLElement
                  if (preferencesTab) preferencesTab.click()
                }, 100)
              }}
            >
              <Settings className="mr-2 h-4 w-4" />
              <span>Settings</span>
            </DropdownMenuItem>
          </DropdownMenuGroup>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onSignOut}>
            <LogOut className="mr-2 h-4 w-4" />
            <span>Log out</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <ProfileModal
        open={profileModalOpen}
        onClose={() => setProfileModalOpen(false)}
        username={username}
        accountBalance={accountBalance}
        profilePicture={profilePicture}
        onBalanceUpdate={onBalanceUpdate}
        onProfileUpdate={handleProfileUpdate}
      />
    </div>
  )
}
