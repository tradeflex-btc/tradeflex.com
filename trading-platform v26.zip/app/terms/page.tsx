import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function TermsPage() {
  return (
    <div className="container max-w-4xl py-12">
      <Link href="/" className="flex items-center text-sm mb-8 hover:underline">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Dashboard
      </Link>

      <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>

      <div className="prose prose-sm dark:prose-invert max-w-none">
        <p className="text-muted-foreground mb-4">Last updated: April 18, 2024</p>

        <h2 className="text-xl font-semibold mt-8 mb-4">1. Introduction</h2>
        <p>
          Welcome to TradeFlex. These Terms of Service govern your use of our website and trading platform. By accessing
          or using TradeFlex, you agree to be bound by these Terms. If you disagree with any part of the terms, you may
          not access the service.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">2. Accounts</h2>
        <p>
          When you create an account with us, you must provide information that is accurate, complete, and current at
          all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of
          your account on our platform.
        </p>
        <p>
          You are responsible for safeguarding the password that you use to access the service and for any activities or
          actions under your password. You agree not to disclose your password to any third party. You must notify us
          immediately upon becoming aware of any breach of security or unauthorized use of your account.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">3. Trading Risks</h2>
        <p>
          Trading in financial instruments, including cryptocurrencies, stocks, and other assets, involves significant
          risk. You should carefully consider your investment objectives, level of experience, and risk appetite before
          engaging in trading activities.
        </p>
        <p>
          Past performance is not indicative of future results. The value of investments can go down as well as up, and
          you may lose some or all of your invested capital. TradeFlex does not provide investment advice, and nothing
          on this platform should be construed as investment advice.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">4. Fees and Charges</h2>
        <p>
          TradeFlex may charge fees for certain services, including but not limited to trading commissions, deposit
          fees, withdrawal fees, and account maintenance fees. All applicable fees will be clearly disclosed before you
          complete a transaction.
        </p>
        <p>
          We reserve the right to modify our fee structure at any time. Changes to fees will be announced on our
          platform and will take effect after a reasonable notice period.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">5. Intellectual Property</h2>
        <p>
          The TradeFlex platform and its original content, features, and functionality are and will remain the exclusive
          property of TradeFlex and its licensors. The platform is protected by copyright, trademark, and other laws of
          both the United States and foreign countries.
        </p>
        <p>
          Our trademarks and trade dress may not be used in connection with any product or service without the prior
          written consent of TradeFlex.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">6. Termination</h2>
        <p>
          We may terminate or suspend your account immediately, without prior notice or liability, for any reason
          whatsoever, including without limitation if you breach the Terms.
        </p>
        <p>
          Upon termination, your right to use the platform will immediately cease. If you wish to terminate your
          account, you may simply discontinue using the platform or contact us to request account deletion.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">7. Limitation of Liability</h2>
        <p>
          In no event shall TradeFlex, nor its directors, employees, partners, agents, suppliers, or affiliates, be
          liable for any indirect, incidental, special, consequential or punitive damages, including without limitation,
          loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or
          inability to access or use the platform.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">8. Governing Law</h2>
        <p>
          These Terms shall be governed and construed in accordance with the laws of the United States, without regard
          to its conflict of law provisions.
        </p>
        <p>
          Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights.
          If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of
          these Terms will remain in effect.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">9. Changes to Terms</h2>
        <p>
          We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is
          material, we will try to provide at least 30 days' notice prior to any new terms taking effect.
        </p>
        <p>
          By continuing to access or use our platform after those revisions become effective, you agree to be bound by
          the revised terms. If you do not agree to the new terms, please stop using the platform.
        </p>

        <h2 className="text-xl font-semibold mt-8 mb-4">10. Contact Us</h2>
        <p>If you have any questions about these Terms, please contact us at support@tradeflex.com.</p>
      </div>
    </div>
  )
}
